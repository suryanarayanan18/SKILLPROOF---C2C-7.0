import re

files_to_check = [
    'frontend/skill_selection/code.html',
    'frontend/skillproof_assessments_hub/code.html',
    'frontend/skillproof_ai_analysis_performance_intelligence/code.html',
    'frontend/ai_evaluation_performance_report/code.html',
    'frontend/skillproof_consolidated_skill_passport/code.html',
    'frontend/skillproof_assessment_history/code.html',
    'frontend/skillproof_challenge_workspace/code.html',
]

for filepath in files_to_check:
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    print(f"\n==================== {filepath} ====================")
    # Check if flow.js is loaded
    has_flow = 'flow.js' in content
    print("Has flow.js:", has_flow)

    # Check style tag at top
    style_matches = re.findall(r'<style[^>]*>(.*?)</style>', content, re.DOTALL)
    for s in style_matches:
        if 'overflow' in s or 'scrollbar' in s:
            print("Style snippet:", s[:200].replace('\n', ' '))

    # Check main tag
    main_match = re.search(r'<main[^>]*>', content)
    if main_match:
        print("Main tag:", main_match.group(0))

    # Check if bottom of main has padding
    sections = re.findall(r'<(section|div|footer)[^>]*class="[^"]*(?:pb-|mb-|bottom)[^"]*"', content)
    print("Found bottom padding classes count:", len(sections))
