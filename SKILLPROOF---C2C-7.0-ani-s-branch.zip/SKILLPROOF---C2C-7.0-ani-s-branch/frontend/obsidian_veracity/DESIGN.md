---
name: Obsidian Veracity
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#d8c1c2'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#a08c8d'
  outline-variant: '#534344'
  surface-tint: '#ffb2b9'
  primary: '#ffb2b9'
  on-primary: '#571c26'
  primary-container: '#cb7a83'
  on-primary-container: '#4e1520'
  inverse-primary: '#904952'
  secondary: '#ffb4a5'
  on-secondary: '#5a1b10'
  secondary-container: '#773124'
  on-secondary-container: '#fd9b88'
  tertiary: '#ffb1c3'
  on-tertiary: '#521f2e'
  tertiary-container: '#c27d8e'
  on-tertiary-container: '#4a1928'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdadc'
  primary-fixed-dim: '#ffb2b9'
  on-primary-fixed: '#3b0712'
  on-primary-fixed-variant: '#73323b'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a5'
  on-secondary-fixed: '#3d0601'
  on-secondary-fixed-variant: '#773124'
  tertiary-fixed: '#ffd9e0'
  tertiary-fixed-dim: '#ffb1c3'
  on-tertiary-fixed: '#380a1a'
  on-tertiary-fixed-variant: '#6d3545'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  display-xl:
    fontFamily: Geist
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.035em
  display-xl-mobile:
    fontFamily: Geist
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  space-4xl: 6rem
  container-padding-mobile: 1.25rem
  container-padding-desktop: 3rem
  gutter-default: 1.5rem
  max-width-app: 1440px
---

## Brand & Style

This design system delivers an authoritative, high-stakes verification environment for technical talent and enterprise evaluators. Designed to convey rigor, institutional permanence, and calibrated precision, the visual language avoids Silicon Valley cliches, playful gamification, crypto fluorescents, and electric blue/purple lighting.

The aesthetic philosophy centers on **Cinematic Minimalism with Obsidian Precision**:
- **Atmosphere:** Deep, architectural shadows punctuated by warm wine, burgundy, and terracotta undertones. It mirrors the feeling of an executive testing room, a luxury horology atelier, or an archival terminal.
- **Tone:** Methodical, unhurried, rigorous, and definitive. The UI reassures enterprise leaders that evaluations are empirically grounded while treating candidates with dignity.
- **Physicality:** Matte obsidian plates, delicate directional wireframes (1px translucent borders), and diffused sub-surface burgundy radiance that illuminates structural state changes rather than decorating them.

## Colors

The palette is engineered for prolonged visual focus in low-light environments, relying on deep neutral values with warm micro-temperatures rather than harsh true blacks.

### Foundation & Surfaces
- **Canvas Root:** `#050405` (Deepest Obsidian Abyss)
- **Layer 0 (Base Canvas):** `#080709` (Charcoal Tint)
- **Layer 1 (Card/Container Base):** `#0A0A0B` (Standard Dark Field)
- **Layer 2 (Elevated Panels):** `#111012` (Elevated Obsidian)
- **Layer 3 (Modals/Overlays):** `#151315` (Lifted Slate Charcoal)
- **Layer 4 (Interactive States):** `#191619` to `#1D191C` (Focused/Hover Wells)

### Typography & Content
- **Primary Ink:** `#F5F3F3` (Crisp Chalk White, 95% opacity equivalent on dark)
- **Secondary Ink:** `#C8C1C3` (Warm Ash Silver, 78% contrast ratio for structural body)
- **Muted Ink:** `#8D8789` (Deep Pumice, 50% contrast ratio for metadata and labels)
- **Structural Lines:** `rgba(245, 243, 243, 0.07)` to `rgba(245, 243, 243, 0.12)`

### Accent Tiers (Burgundy, Wine & Rose Ochre)
- **Deep Wine Accent:** `#8A4D5D` (Subtle boundary glows, subdued badge fills)
- **Muted Burgundy (Brand Core):** `#B86A73` (Primary focal points, active state indicators)
- **Terracotta Rose Highlight:** `#D47A68` (High-priority indicators, gradient termination endpoints)
- **Soft Blush Highlights:** `#D9A0AA` and `#E5C1C4` (Subtle micro-copy accents, badge strokes)

### Analytical & System Semantics
- **Analytical Metrics:** `#78BDE8` to `#A7D8F0` (Restrained ice blue reserved solely for code evaluation and statistical benchmarking)
- **Verification Success:** `#6FA879` (Tempered sage green, never neon)
- **Verification Warning:** `#D69A5B` (Burnished ochre)
- **Verification Error/Critical:** `#C86B73` (Oxblood vermilion)

## Typography

The typography system demands high optical tension, micro-tuned tracking, and immediate legibility across information-dense layouts.

- **Primary Typeface:** `Geist` is deployed across all standard headers, functional UI, and numerical representations for its crisp geometric terminals and clean vertical metrics.
- **Monospace Companion:** `JetBrains Mono` handles all evaluation hashes, runtime traces, latency logs, and code verification tokens.
- **Typographic Treatment:**
  - Headers utilize negative tracking (`-0.02em` to `-0.035em`) with semi-bold weights to command authority without appearing heavy-handed.
  - Labels and micro-metadata apply gentle positive tracking (`+0.04em` to `+0.05em`) with all-caps styling to establish categorical taxonomy.
  - Body copy uses relaxed line-height ratios (`1.55` to `1.625`) to preserve eye comfort during in-depth assessment readings.

## Layout & Spacing

This design system uses a strict **8px base rhythmic grid** coupled with an architectural **12-column layout** for desktop screens and a **4-column layout** on mobile devices.

### Breakpoints & Fluidity
- **Desktop (>= 1280px):** 12 columns, `1.5rem` (24px) gutters, max-width constrained to `1440px` centered with variable margins. Generous spatial paddings establish a quiet, gallery-level focus.
- **Tablet (768px - 1279px):** 8 columns, `1rem` (16px) gutters, `2rem` outer padding. Two-column analysis cards reflow into structured single-column vertical stacks.
- **Mobile (< 768px):** 4 columns, `0.75rem` (12px) gutters, `1.25rem` outer canvas padding. Density remains high; non-essential visual halos are hidden to preserve processing performance and readability.

### Structural Discipline
Spacing around evaluation metrics must stay consistent. Group headers and their child content share an immediate `0.5rem` gap, while distinct logical modules are separated by an unequivocal `2rem` to `3rem` rhythm.

## Elevation & Depth

Visual hierarchy is communicated through structural lighting and physical layering rather than dramatic, unrealistic shadow drop-offs.

### The Obsidian Stacking Model
1. **Baseplate (`#050405` to `#080709`):** Deep canvas that anchors the interface.
2. **Structural Tiles (`#0A0A0B` / `#111012`):** Bordered with hairline `1px solid rgba(245, 243, 243, 0.07)` to establish physical containment without visual clutter.
3. **Elevated Trays (`#151315`):** Reserved for popovers, flyouts, and active evaluation boards. Surrounded by `1px solid rgba(245, 243, 243, 0.12)` with shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.65)`.

### The Burgundy Ambient Glow
To reflect genuine skill verification, high-tier credentials and primary focus cards employ the signature **Sub-surface Glow**:
- A radial gradient is cast from behind the card container: `radial-gradient(circle at 50% 0%, rgba(184, 106, 115, 0.14), transparent 70%)`.
- The top boundary of the card receives a micro-highlight: a gradient border interpolating from `rgba(212, 122, 104, 0.35)` to `rgba(138, 77, 93, 0.05)`.
- Shadows are deep, warm, and tightly controlled: `0 24px 48px -12px rgba(5, 4, 5, 0.8), 0 0 40px -10px rgba(138, 77, 93, 0.12)`.

## Shapes

The geometric framework balances organic ease with architectural discipline:
- **Macro Components (Panels, Large Verification Cards, Modals):** Scaled to `1.5rem` (24px) or `2rem` (32px) corner radii. This generous curvature softens the dark aesthetic, creating an expansive, modern, executive silhouette.
- **Intermediate Components (Input fields, nested sections, secondary cards):** Strict `0.875rem` (14px) to `1.25rem` (20px) radius to maintain high visual alignment with parent boundaries.
- **Micro Elements (Buttons, Badges, Tabs):** `0.5rem` (8px) to `0.75rem` (12px) for sharp structural confidence.
- **Pill Profiles:** Exclusively reserved for status indicators, numeric benchmark pills, and state tags.

## Components

### Buttons
- **Primary Verifier (High-Contrast Hero):** Solid chalk `#F5F3F3` surface with pitch-black `#0A0A0B` text in font-weight 600. Active states drop to `#C8C1C3`. This stark inverted contrast commands undisputed visual priority.
- **Signature Radiant:** Gradient surface blending from warm burgundy through rose ochre (`linear-gradient(135deg, #8A4D5D 0%, #B86A73 50%, #D47A68 100%)`) with chalk `#F5F3F3` text. Subtle outer burgundy rim shadow.
- **Secondary / Ghost Surface:** Transparent base, `1px` stroke in `rgba(245, 243, 243, 0.12)`, subtle `#111012` fill on hover with a smooth 150ms transition.
- **Timing Curve:** All button states transition using `cubic-bezier(0.16, 1, 0.3, 1)`.

### Cards & Verification Surfaces
- **Passive Information Cards:** `#0A0A0B` fill, `1px` perimeter stroke (`rgba(245, 243, 243, 0.07)`), `24px` border-radius.
- **Glowing Benchmark Cards:** Active assessments feature a subtle burgundy-to-terracotta halo behind the panel (`filter: blur(48px)`), a top-lit edge highlight (`1px` gradient border fading to transparent on the sides), and an internal surface fill of `#111012`.

### Badges & Verification Chips
- **Neutral Indicator:** Base `#151315`, border `rgba(245, 243, 243, 0.1)`, text `#C8C1C3`, padding `4px 10px`, font size `11px`, letter spacing `0.04em`.
- **Verified Competency:** Base `rgba(111, 168, 121, 0.08)`, border `rgba(111, 168, 121, 0.25)`, text `#6FA879`.
- **Evaluation Grade:** Base `rgba(184, 106, 115, 0.12)`, border `rgba(184, 106, 115, 0.3)`, text `#E5C1C4`.

### Form Fields & Inputs
- **Base Surface:** `#080709` cavity embedded within `#111012` card structures.
- **Height & Typography:** Standard 44px height; text in `14px` (`#F5F3F3`), placeholder in `#8D8789`.
- **Focus Mechanism:** Crisp `1px` border shift to `#B86A73` with a subdued `0 0 0 3px rgba(184, 106, 115, 0.15)` focus ring. Never use default OS blue rings.

### Checkboxes & Segmented Selectors
- **Unchecked:** Flat `#151315` box with subtle `rgba(245, 243, 243, 0.18)` outline; 6px corner radius.
- **Checked:** Filled with `#B86A73`; check glyph rendered in `#F5F3F3`.
- **Segmented Controls:** Contained obsidian channel (`#080709`) with an elevated pill thumb (`#1D191C`) sliding under active selections.

### Analytics & Code Proof Blocks
- **Code Terminal:** `#050405` surface, `JetBrains Mono` text, subtle status pulse using muted analytics blue (`#78BDE8`).
- **Telemetry Bars:** Slate background tracks with progressive fill in single muted hues (either `#B86A73` or `#78BDE8`); never display multicolored rainbow indicators.