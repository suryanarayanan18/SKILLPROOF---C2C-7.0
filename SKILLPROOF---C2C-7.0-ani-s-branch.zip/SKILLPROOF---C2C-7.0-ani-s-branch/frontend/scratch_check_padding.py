import re

pages = [
    'frontend/skillproof_assessments_hub/code.html',
    'frontend/skillproof_ai_analysis_performance_intelligence/code.html',
    'frontend/ai_evaluation_performance_report/code.html',
    'frontend/skillproof_consolidated_skill_passport/code.html',
    'frontend/skillproof_assessment_history/code.html',
    'frontend/difficulty_selection/code.html',
    'frontend/assessment_setup/code.html'
]

for p in pages:
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()
    m = re.search(r'<main[^>]*>(.*?)</main>', c, re.DOTALL)
    if m:
        main_content = m.group(1)
        first_div = re.search(r'<div class="([^"]*)"', main_content)
        if first_div:
            cls = first_div.group(1)
            print(f"{p}: {cls}")
