import glob
import re

for f in sorted(glob.glob('frontend/**/*.html', recursive=True)):
    with open(f, 'r', encoding='utf-8') as fp:
        c = fp.read()
    links = re.findall(r'data-path="([^"]+)"', c)
    if links:
        print(f"{f}: {links}")
