/**
 * SkillProof API Client Module
 * Provides standardized interface to backend REST endpoints.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.SkillProofAPI = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function getClient() {
    if (typeof window !== 'undefined' && window.SkillProof && window.SkillProof.API) {
      return window.SkillProof.API;
    }
    return {
      baseUrl: 'http://127.0.0.1:8000',
      async request(endpoint, options = {}) {
        const response = await fetch(`${this.baseUrl}${endpoint}`, {
          headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
          ...options,
        });
        if (!response.ok) {
          throw new Error(`API error: ${response.status}`);
        }
        return await response.json();
      },
      health() { return this.request('/api/health'); },
      createChallenge(skill, difficulty) {
        return this.request('/api/challenges', {
          method: 'POST',
          body: JSON.stringify({ skill, difficulty }),
        });
      },
      submitSolution(assessmentId, solution, timeElapsedSeconds = 0) {
        return this.request(`/api/assessments/${assessmentId}/submit`, {
          method: 'POST',
          body: JSON.stringify({ solution, time_elapsed_seconds: timeElapsedSeconds }),
        });
      },
      getAssessment(assessmentId) {
        return this.request(`/api/assessments/${assessmentId}`);
      },
      getPassport() {
        return this.request('/api/passport');
      },
      executeCode(code, language = 'python', stdin = '') {
        return this.request('/api/execute', {
          method: 'POST',
          body: JSON.stringify({ code, language, stdin }),
        });
      },
      runTests(assessmentId, code, language = 'python', customTests = []) {
        return this.request('/api/tests/run', {
          method: 'POST',
          body: JSON.stringify({
            assessment_id: assessmentId,
            code,
            language,
            custom_tests: customTests,
          }),
        });
      },
      getJDoodleStatus() {
        return this.request('/api/jdoodle/status');
      },
      configureJDoodle(clientId, clientSecret) {
        return this.request('/api/config/jdoodle', {
          method: 'POST',
          body: JSON.stringify({ client_id: clientId, client_secret: clientSecret }),
        });
      },
    };
  }

  return {
    health: () => getClient().health(),
    createChallenge: (s, d) => getClient().createChallenge(s, d),
    submitSolution: (id, sol, t) => getClient().submitSolution(id, sol, t),
    getAssessment: (id) => getClient().getAssessment(id),
    getPassport: () => getClient().getPassport(),
    executeCode: (code, lang, stdin) => getClient().executeCode(code, lang, stdin),
    runTests: (id, code, lang, tests) => getClient().runTests(id, code, lang, tests),
    getJDoodleStatus: () => getClient().getJDoodleStatus(),
    configureJDoodle: (id, secret) => getClient().configureJDoodle(id, secret),
  };
});
