import os
import re

SCROLLBAR_CSS = """@layer base{html,body{margin:0;padding:0;min-height:100%;}html{overflow-y:scroll;scroll-behavior:smooth;}}
::-webkit-scrollbar{width:8px;height:8px;}
::-webkit-scrollbar-track{background:#131314;}
::-webkit-scrollbar-thumb{background:rgba(203,122,131,0.35);border-radius:4px;}
::-webkit-scrollbar-thumb:hover{background:rgba(203,122,131,0.65);}"""

# 1. Fix head structure in the 3 files
head_files = {
    'frontend/ai_evaluation_performance_report/code.html': 'Assessment Complete | Deterministic Verification Report',
    'frontend/skillproof_ai_analysis_performance_intelligence/code.html': 'AI Performance Intelligence & Diagnostics',
    'frontend/skillproof_consolidated_skill_passport/code.html': 'Consolidated Skill Passport | Verified Credentials'
}

for fpath, title in head_files.items():
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Pattern: <!DOCTYPE html><html...><head></head><body...><svg...>(head contents)</script><aside
    pattern = re.compile(
        r'(<!DOCTYPE html>\s*<html[^>]*>)\s*<head></head>\s*(<body[^>]*>)\s*(<svg[^>]*>.*?</svg>)(.*?)(</script>)(\s*<aside)',
        re.DOTALL
    )
    m = pattern.search(content)
    if m:
        html_open = m.group(1)
        body_open = m.group(2)
        svg_elem = m.group(3)
        head_elements = m.group(4) + m.group(5)
        aside_open = m.group(6)

        # Replace hidden scrollbar inside head_elements
        head_elements = re.sub(
            r'@layer base\{html,body\{margin:0;padding:0;\}body\{overscroll-behavior:none;\}main>:first-child\{margin-top:0!important;\}main>:last-child\{margin-bottom:0!important;\}\}::-webkit-scrollbar\{display:none;\}',
            SCROLLBAR_CSS,
            head_elements
        )

        new_head = f"""{html_open}
<head>
<title>{title} — SkillProof</title>
{head_elements}
</head>
{body_open}
{svg_elem}
{aside_open}"""

        new_content = content[:m.start()] + new_head + content[m.end():]
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Fixed head in {fpath}")
    else:
        print(f"Pattern did not match in {fpath}")

# 2. Fix scrollbar CSS in other files
all_html_files = [
    'frontend/skillproof_assessments_hub/code.html',
    'frontend/skillproof_assessment_history/code.html',
    'frontend/difficulty_selection/code.html',
    'frontend/assessment_setup/code.html',
    'frontend/skillproof_console_ui_system/code.html'
]

for fpath in all_html_files:
    with open(fpath, 'r', encoding='utf-8') as f:
        c = f.read()
    old_c = c
    c = re.sub(
        r'@layer base\{html,body\{margin:0;padding:0;\}body\{overscroll-behavior:none;\}main>:first-child\{margin-top:0!important;\}main>:last-child\{margin-bottom:0!important;\}\}::-webkit-scrollbar\{display:none;\}',
        SCROLLBAR_CSS,
        c
    )
    # also check if just ::-webkit-scrollbar{display:none;} remains
    c = re.sub(r'::-webkit-scrollbar\{display:none;\}', '::-webkit-scrollbar{width:8px;height:8px;}::-webkit-scrollbar-track{background:#131314;}::-webkit-scrollbar-thumb{background:rgba(203,122,131,0.35);border-radius:4px;}', c)
    if c != old_c:
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(c)
        print(f"Updated scrollbar in {fpath}")
