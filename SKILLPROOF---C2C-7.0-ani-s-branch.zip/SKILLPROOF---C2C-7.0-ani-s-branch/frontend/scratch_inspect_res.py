import urllib.request, json

def post_json(path, data):
    body = json.dumps(data).encode('utf-8')
    req = urllib.request.Request('http://127.0.0.1:8000' + path, data=body, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode('utf-8'))

res_cpp = post_json('/api/execute', {
    'code': '#include <iostream>\nint main() { std::cout << "SkillProof CPP Verified!" << std::endl; return 0; }',
    'language': 'cpp'
})
print('CPP EXECUTE:', res_cpp)

res_html = post_json('/api/execute', {
    'code': '<!DOCTYPE html><html><body><h1>Semantic Proof</h1></body></html>',
    'language': 'html'
})
print('HTML EXECUTE:', res_html)

res_test = post_json('/api/tests/run', {
    'code': 'import sys\na = int(sys.stdin.readline())\nb = int(sys.stdin.readline())\nprint(a + b)',
    'language': 'python',
    'tests': [{'name': 'T1', 'input': '2\n3', 'expected_output': '5'}]
})
print('PYTHON TEST RUN:', res_test)
