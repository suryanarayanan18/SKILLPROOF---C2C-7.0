import json
import urllib.request
import sys

BASE_URL = "http://127.0.0.1:8000"

SKILLS = [
    "Python", "JavaScript", "C++", "HTML"
]


DIFFICULTIES = ["beginner", "intermediate", "advanced"]

def run_test():
    print(f"Testing against {BASE_URL}...")
    # 1. Health check
    req = urllib.request.Request(f"{BASE_URL}/api/health")
    with urllib.request.urlopen(req) as res:
        health = json.loads(res.read())
        print(f"Health OK: {health}")

    # 2. Test challenges for all skills and difficulties in demo mode
    passed = 0
    total = len(SKILLS) * len(DIFFICULTIES)

    for skill in SKILLS:
        for diff in DIFFICULTIES:
            body = json.dumps({"skill": skill, "difficulty": diff}).encode("utf-8")
            req = urllib.request.Request(
                f"{BASE_URL}/api/challenges",
                data=body,
                headers={"Content-Type": "application/json", "X-Demo-Mode": "true"},
            )
            try:
                with urllib.request.urlopen(req) as res:
                    if res.status == 201:
                        data = json.loads(res.read())
                        assert data["assessment_id"], "Missing assessment_id"
                        assert data["skill"].lower() == skill.lower(), f"Skill mismatch: {data['skill']} vs {skill}"
                        assert data["starter_code"], "Missing starter_code"
                        assert data["task"], "Missing task"
                        passed += 1
                    else:
                        print(f"FAILED {skill} {diff}: status {res.status}")
            except Exception as e:
                print(f"ERROR on {skill} {diff}: {e}")

    print(f"\nCompleted {passed}/{total} skill+difficulty combinations successfully!")

    # 3. Test submission flow
    print("\nTesting full submission flow on Python intermediate...")
    create_body = json.dumps({"skill": "Python", "difficulty": "intermediate"}).encode("utf-8")
    req = urllib.request.Request(
        f"{BASE_URL}/api/challenges",
        data=create_body,
        headers={"Content-Type": "application/json", "X-Demo-Mode": "true"},
    )
    with urllib.request.urlopen(req) as res:
        challenge = json.loads(res.read())
        a_id = challenge["assessment_id"]

    sub_body = json.dumps({
        "solution": challenge["starter_code"],
        "time_elapsed_seconds": 45
    }).encode("utf-8")
    sub_req = urllib.request.Request(
        f"{BASE_URL}/api/assessments/{a_id}/submit",
        data=sub_body,
        headers={"Content-Type": "application/json", "X-Demo-Mode": "true"},
    )
    with urllib.request.urlopen(sub_req) as res:
        eval_data = json.loads(res.read())
        assert eval_data["evaluation"], "Missing evaluation"
        print(f"Submission evaluation OK: Overall Score = {eval_data['evaluation']['overall_score']}")

    print("\nALL FLOW TESTS PASSED!")

if __name__ == "__main__":
    run_test()
