import urllib.request
import json
import time

BASE_URL = "http://127.0.0.1:8000"

for skill in ['Python', 'C++', 'HTML']:
    for diff in ['beginner', 'intermediate', 'advanced']:
        t0 = time.time()
        try:
            payload = json.dumps({'skill': skill, 'difficulty': diff}).encode()
            req = urllib.request.Request(
                f"{BASE_URL}/api/challenges",
                data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=40) as res:
                body = json.loads(res.read().decode())
                elapsed = time.time() - t0
                title = body.get('title', 'NO_TITLE')
                code_len = len(body.get('starter_code', ''))
                print(f"[OK] {skill:7} {diff:12} ({elapsed:.1f}s) | Title: {title[:35]} | Starter: {code_len}b | Examples: {len(body.get('examples', []))}")
        except Exception as e:
            elapsed = time.time() - t0
            print(f"[FAIL] {skill:7} {diff:12} ({elapsed:.1f}s) | Error: {e}")
