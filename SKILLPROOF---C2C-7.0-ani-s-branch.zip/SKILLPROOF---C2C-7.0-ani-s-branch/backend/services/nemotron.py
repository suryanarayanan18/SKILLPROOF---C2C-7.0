"""NVIDIA Nemotron integration for SkillProof."""

import os
import re
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env")
load_dotenv(Path(__file__).resolve().parents[2] / ".env")


def _get_client(api_key: str | None = None, timeout: float = 4.0):
    """Create the OpenAI-compatible NVIDIA NIM client."""
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("openai is not installed.") from exc

    key = api_key or os.getenv("NVIDIA_API_KEY") or os.getenv("NEMOTRON_API_KEY") or ""
    if not key:
        raise RuntimeError("NVIDIA_API_KEY is not set. Please provide a valid NVIDIA API key.")

    return OpenAI(
        base_url="https://integrate.api.nvidia.com/v1",
        api_key=key,
        timeout=timeout,
        max_retries=0,
    )


def generate_text(prompt: str, api_key: str | None = None, timeout: float = 6.0) -> str:
    """Send a prompt to NVIDIA Nemotron and return the generated text.

    Strictly calls the live NVIDIA Nemotron model. No mock or demo fallback.
    """
    client = _get_client(api_key, timeout=timeout)
    configured_model = os.getenv("NVIDIA_MODEL", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning")
    candidate_models = [configured_model]
    for fallback in ["nvidia/nemotron-3.5-lightning-30b-a3b", "nvidia/nemotron-3-super-120b-a12b"]:
        if fallback not in candidate_models:
            candidate_models.append(fallback)

    last_error = None
    for model_name in candidate_models:
        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=1500,
            )
            text = response.choices[0].message.content or ""
            text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
            if text:
                return text
        except Exception as exc:
            last_error = exc
            err_msg = str(exc).lower()
            if "timeout" in err_msg or "timed out" in err_msg:
                raise exc
            # Only retry if it is a transient worker limit / 503 / 429
            if any(marker in err_msg for marker in ("503", "resourceexhausted", "429")):
                continue
            raise exc

    if last_error:
        raise last_error
    return ""
