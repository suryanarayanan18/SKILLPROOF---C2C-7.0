import os
from pathlib import Path

from dotenv import load_dotenv

# Resolve the repository-level and backend-level files explicitly
load_dotenv(Path(__file__).resolve().parents[1] / ".env")
load_dotenv(Path(__file__).resolve().parents[2] / ".env")


def _get_client():
    """Create the Gemini client only when a request actually needs it."""
    try:
        from google import genai
    except ImportError as exc:
        raise RuntimeError("google-genai is not installed.") from exc

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not set.")
    return genai.Client(api_key=api_key)


def generate_text(prompt: str, timeout: float = 6.0) -> str:
    """Send a prompt to Gemini and return the generated text."""

    client = _get_client()
    model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    response = client.models.generate_content(
        model=model_name,
        contents=prompt,
    )

    return response.text


def generate_challenge(
    skill: str = "Python",
    difficulty: str = "beginner",
    previous_performance: str | None = None,
    target_weakness: str | None = None,
) -> str:
    """Generate a practical skill assessment challenge using Gemini."""
    skill_lower = skill.strip().lower()
    if skill_lower in ("c++", "cpp"):
        skill_guidelines = """For a C++ challenge, include:
- A clear problem statement testing algorithmic logic, systems thinking, standard library (STL) usage, or memory safety.
- The user's task (e.g., implementing a function or class).
- Input/output expectations and performance constraints.
- Starter code with standard headers (#include <iostream>, <vector>, etc.) and function/class signatures.
- At least one concrete example."""
    elif skill_lower in ("html", "html5"):
        skill_guidelines = """For an HTML challenge, include:
- A clear specification for building or repairing semantic, accessible HTML markup.
- The user's task (e.g., creating an accessible form, semantic layout, landmark roles, or responsive navigation structure).
- Requirements for semantic tags, web accessibility (a11y / ARIA / label bindings), and DOM structure.
- Starter code with clean HTML boilerplate or initial element scaffolding.
- At least one example showing expected element hierarchy."""
    elif skill_lower in ("javascript", "js"):
        skill_guidelines = """For a JavaScript challenge, include:
- A clear problem statement testing asynchronous logic, DOM manipulation, state patterns, or ES2024 features.
- The user's task (e.g., implementing an async transformer or stateful handler).
- Input/output expectations and runtime constraints.
- Starter code with function signatures and clear comments.
- At least one concrete example."""
    else:
        skill_guidelines = """For a Python challenge, include:
- A clear problem statement testing algorithmic efficiency, data structures, and clean idiomatic code.
- The user's task.
- Input/output expectations and constraints (PEP 8 compliance).
- Starter code with type hints and docstring.
- At least one concrete example."""

    prompt = f"""
You are the Challenge Generator for SkillProof,
an AI-powered practical skill verification platform.

Your job is to create a practical assessment challenge
that tests real ability rather than memorization.

Skill:
{skill}

Difficulty:
{difficulty}

Previous performance:
{previous_performance or "No previous performance. This is the first challenge."}

Target weakness:
{target_weakness or "No specific weakness. Test a balanced set of skills."}

Create ONE practical challenge.

The challenge must:

1. Be appropriate for the selected difficulty.
2. Test practical problem-solving ability.
3. Require the user to actually produce a solution.
4. Avoid questions that can be answered through simple memorization.
5. Be realistic and useful for evaluating professional ability.

{skill_guidelines}

Do NOT provide the solution.

Return ONLY a JSON object. Its fields must be:
title (string), overview (string), task (string), constraints (array of strings),
starter_code (string), and examples (array of objects with input and output strings).
Do not wrap the JSON in Markdown or include a solution.
"""
    return generate_text(prompt)


def evaluate_solution(
    challenge: str,
    solution: str,
    skill: str = "Python",
    difficulty: str | None = None,
) -> str:
    """Evaluate candidate solution using Gemini."""
    skill_lower = skill.strip().lower()
    if skill_lower in ("c++", "cpp"):
        criteria_guidelines = """C++ Evaluation Focus:
- Correctness against problem requirements & edge cases
- Memory safety (no buffer overflows, resource leaks, or undefined behavior)
- Modern C++ idioms (STL algorithms/containers, RAII, const-correctness)
- Algorithmic efficiency (optimal time/space Big-O)"""
    elif skill_lower in ("html", "html5"):
        criteria_guidelines = """HTML Evaluation Focus:
- Semantic markup (appropriate semantic elements <main>, <nav>, <header>, <article>, <section>, <form>, <button> etc.)
- Web accessibility / a11y (ARIA roles/labels, form control associations, alt attributes, heading hierarchies)
- Valid HTML structure and syntax
- Form input validation attributes and clean DOM nesting"""
    elif skill_lower in ("javascript", "js"):
        criteria_guidelines = """JavaScript Evaluation Focus:
- Correctness and edge case handling
- Proper asynchronous handling (Promises, async/await, error handling)
- Modern ES2024 idioms (destructuring, clean scoping, arrow functions)
- Modularity and algorithmic efficiency"""
    else:
        criteria_guidelines = """Python Evaluation Focus:
- Correctness and edge case handling
- PEP 8 compliance and Pythonic style
- Algorithmic efficiency (optimal time and memory complexity)
- Clean error handling and validation"""

    prompt = f"""
You are the SkillProof AI Evaluator.

SkillProof is an AI-powered practical skill verification platform.
The goal is to evaluate REAL ability rather than certificates.

SKILL:
{skill}

DIFFICULTY:
{difficulty or "standard"}

CHALLENGE:
{challenge}

CANDIDATE'S SOLUTION:
{solution}

Evaluate the candidate's solution carefully.

IMPORTANT:
- Do not give credit simply because the code looks plausible.
- Check whether the solution actually solves the stated problem.
- Consider edge cases.
- Evaluate the candidate's reasoning and implementation quality.
- Be fair to a beginner/intermediate/advanced candidate depending on the challenge.
- Do not invent requirements that were not present in the challenge.

{criteria_guidelines}

Return ONLY a JSON object with overall_score, correctness, problem_solving,
code_quality, efficiency, understanding, practical_application (all integers
from 0 to 100), summary, strengths (array), weaknesses (array), feedback, and
recommended_next_step. Do not wrap the JSON in Markdown. Be concise but specific.
"""
    return generate_text(prompt)
