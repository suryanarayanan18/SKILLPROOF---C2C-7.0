import json
import logging
import os
import re
from typing import Any

import services.nemotron as nemotron

logger = logging.getLogger("skillproof.evaluator")


def _generate_with_provider(prompt: str, timeout: float = 4.0) -> str:
    provider = os.getenv("SKILLPROOF_PROVIDER", "").strip().lower()
    if provider == "gemini" or (os.getenv("GEMINI_API_KEY") and not os.getenv("NVIDIA_API_KEY")):
        import services.gemini as gemini
        return gemini.generate_text(prompt)
    return nemotron.generate_text(prompt, timeout=timeout)


def _build_deterministic_evaluation(
    challenge: str,
    solution: str,
    skill: str,
    difficulty: str | None,
    test_results: dict[str, Any] | None,
    session_history: dict[str, Any] | None,
) -> str:
    """Deterministic fallback evaluator tied directly to actual test metrics and candidate session history."""
    t_res = test_results or {}
    s_hist = session_history or {}

    total = int(t_res.get("total", 3))
    passed = int(t_res.get("passed", 0))
    failed = int(t_res.get("failed", max(0, total - passed)))
    status = str(t_res.get("status", "PASS" if passed == total and total > 0 else "FAIL"))
    comp_err = t_res.get("compiler_error")
    run_err = t_res.get("runtime_error")

    retries = int(s_hist.get("retries", 0))
    submission_count = int(s_hist.get("submission_count", retries + 1))
    improvement = bool(s_hist.get("improvement_demonstrated", False))

    pass_ratio = passed / total if total > 0 else 0.0

    if comp_err:
        overall = 20
        correctness = 10
        problem_solving = 30
        code_quality = 35
        efficiency = 25
        understanding = 30
        practical_app = 25
        competency = "Needs Remediation"
        summary = f"Code failed to compile with error: {comp_err[:120]}. Candidate must fix syntax/compilation issues."
        strengths = ["Attempted implementation under assessment time constraints"]
        weaknesses = [f"Compilation failure: {comp_err[:100]}", "Solution could not be executed against test cases"]
        feedback = "Focus on verifying syntactic correctness and basic imports before submitting."
        rec_step = "Resolve syntax/compiler errors locally and test with basic sample inputs."
    elif run_err:
        overall = 32
        correctness = 20
        problem_solving = 40
        code_quality = 45
        efficiency = 35
        understanding = 40
        practical_app = 35
        competency = "Needs Remediation"
        summary = f"Runtime exception encountered during execution: {run_err[:120]}."
        strengths = ["Syntax compiled successfully", "Structure aligned with problem interface"]
        weaknesses = [f"Runtime crash: {run_err[:100]}", "Unhandled edge case caused program crash"]
        feedback = "Add defensive null/boundary checks to prevent crashes on non-trivial inputs."
        rec_step = "Trace variable bounds and exception scenarios."
    elif pass_ratio == 1.0:
        # Full pass
        overall = 92 if retries == 0 else 90
        correctness = 98
        problem_solving = 94 if not improvement else 96
        code_quality = 90
        efficiency = 88
        understanding = 92
        practical_app = 94
        competency = "Exemplary" if (difficulty or "").lower() == "advanced" else "Proficient"
        
        bonus_msg = " Candidate demonstrated excellent debugging skills by iteratively resolving previous issues." if improvement else ""
        summary = f"All {passed}/{total} test cases passed successfully with zero errors.{bonus_msg}"
        strengths = [
            f"100% test case pass rate ({passed}/{total} verified)",
            "Robust handling of standard, boundary, and edge conditions",
            "Optimal or near-optimal algorithmic complexity",
        ]
        if improvement:
            strengths.append(f"Resilient problem-solving across {submission_count} submissions with proven progression")
        weaknesses = [
            "Minor style or documentation polish could be added"
        ]
        feedback = f"Outstanding work! Your solution demonstrated solid grasp of {skill} principles and rigorous edge case handling."
        rec_step = f"Advance to next difficulty tier ({'advanced' if (difficulty or '').lower() == 'beginner' else 'expert challenge'})."
    elif pass_ratio >= 0.6:
        # Partial pass (e.g. 2/3)
        overall = 68
        correctness = 65
        problem_solving = 72
        code_quality = 70
        efficiency = 65
        understanding = 70
        practical_app = 68
        competency = "Developing"
        summary = f"Candidate passed {passed}/{total} test cases. Standard cases work, but boundary/edge cases failed."
        strengths = [
            f"Successfully passed {passed} of {total} test cases",
            f"Sound fundamental approach using {skill} idioms",
        ]
        weaknesses = [
            f"Failed {failed} test case(s) on boundary or extreme inputs",
            "Incomplete handling of boundary constraints",
        ]
        feedback = "Your core logic is on the right track, but review boundary limits (e.g. empty, zero, or max values)."
        rec_step = "Review failed test scenarios and refine edge condition handling."
    else:
        # Poor pass (e.g. 0/3 or 1/3)
        overall = 42
        correctness = 35
        problem_solving = 45
        code_quality = 55
        efficiency = 40
        understanding = 45
        practical_app = 40
        competency = "Developing"
        summary = f"Solution passed {passed}/{total} test cases. The output did not match expected results on key criteria."
        strengths = [
            "Submitted complete executable code without syntax crash"
        ]
        weaknesses = [
            f"Failed {failed} of {total} test cases",
            "Logic diverged from stated problem specifications",
        ]
        feedback = "Re-read the problem task description carefully. Check input parsing and output formatting."
        rec_step = "Step through the algorithm with pen and paper on simple examples."

    # Adaptive bonus for candidate demonstrating progression
    if improvement:
        problem_solving = min(100, problem_solving + 5)
        overall = min(100, overall + 3)

    return json.dumps({
        "overall_score": overall,
        "correctness": correctness,
        "problem_solving": problem_solving,
        "code_quality": code_quality,
        "efficiency": efficiency,
        "understanding": understanding,
        "practical_application": practical_app,
        "summary": summary,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "feedback": feedback,
        "recommended_next_step": rec_step,
        "status": "completed",
        "passed_tests": passed,
        "total_tests": total,
        "failed_tests": failed,
        "hidden_tests_passed": passed,
        "hidden_tests_total": total,
        "session_retries": retries,
        "session_submission_count": submission_count,
        "improvement_demonstrated": improvement,
        "competency": competency,
        "improvements": [
            "Consider memory footprint for high volume streams",
            "Add inline documentation for non-trivial algorithm steps",
        ],
        "next_difficulty": "intermediate" if (difficulty or "").lower() == "beginner" else ("advanced" if (difficulty or "").lower() == "intermediate" else "advanced"),
        "test_results": t_res.get("tests", []),
    })


def evaluate_solution(
    challenge: str,
    solution: str,
    skill: str = "Python",
    difficulty: str | None = None,
    test_results: dict[str, Any] | None = None,
    session_history: dict[str, Any] | None = None,
) -> str:
    """
    Evaluate a candidate's solution against a generated challenge.
    Incorporates actual test execution results and session history (retries, errors, progression).
    """
    has_key = bool(os.getenv("NVIDIA_API_KEY") or os.getenv("GEMINI_API_KEY"))

    t_res = test_results or {}
    s_hist = session_history or {}

    total_tests = t_res.get("total", 0)
    passed_tests = t_res.get("passed", 0)
    failed_tests = t_res.get("failed", 0)
    retries = s_hist.get("retries", 0)
    improvement = s_hist.get("improvement_demonstrated", False)

    if has_key:
        prompt = f"""You are the SkillProof AI Evaluator.
Evaluate REAL programming ability rather than memorization.

SKILL: {skill}
DIFFICULTY: {difficulty or 'standard'}

CHALLENGE:
{challenge}

CANDIDATE'S SOLUTION:
{solution}

EXECUTION & TEST RESULTS:
- Total Hidden Tests Executed: {total_tests}
- Passed: {passed_tests}
- Failed: {failed_tests}
- Compiler Error: {t_res.get('compiler_error') or 'None'}
- Runtime Error: {t_res.get('runtime_error') or 'None'}
- Submission Attempt: {s_hist.get('submission_count', 1)}
- Retries: {retries}
- Improvement Demonstrated Across Attempts: {improvement}

EVALUATION GUIDELINES:
1. Strictness: If hidden tests failed or code did not compile, reflect this strictly in correctness and overall_score.
2. Progression: If candidate retried and improved (fixing errors from earlier attempts), reward their problem solving and debugging competence.
3. Be fair to a {difficulty or 'standard'} developer.

Return ONLY a JSON object with:
overall_score, correctness, problem_solving, code_quality, efficiency, understanding,
practical_application (all integers 0-100), summary, strengths (array), weaknesses (array),
feedback, and recommended_next_step. Do not wrap in Markdown.
"""
        raw = _generate_with_provider(prompt, timeout=8.0)
        if raw and raw.strip():
            candidate = raw.strip()
            if candidate.startswith("```"):
                candidate = re.sub(r"^```(?:json)?\s*", "", candidate)
                candidate = re.sub(r"\s*```$", "", candidate)
            try:
                data = json.loads(candidate)
                if isinstance(data, dict) and "overall_score" in data:
                    # Merge in test execution metadata
                    data["passed_tests"] = passed_tests
                    data["total_tests"] = total_tests
                    data["failed_tests"] = failed_tests
                    data["hidden_tests_passed"] = passed_tests
                    data["hidden_tests_total"] = total_tests
                    data["session_retries"] = retries
                    data["session_submission_count"] = s_hist.get("submission_count", 1)
                    data["improvement_demonstrated"] = bool(improvement)
                    return json.dumps(data)
            except Exception:
                pass
            return raw.strip()

    return _build_deterministic_evaluation(
        challenge=challenge,
        solution=solution,
        skill=skill,
        difficulty=difficulty,
        test_results=t_res,
        session_history=s_hist,
    )


if __name__ == "__main__":
    challenge = """
Write a Python function called calculate_total(cart, tax_rate).

Each cart item contains:
- price
- quantity
- discount

Calculate the discounted subtotal and then apply the tax rate.
Return the final amount rounded to 2 decimal places.
"""

    solution = """
def calculate_total(cart, tax_rate):
    subtotal = 0

    for item in cart:
        price = item["price"]
        quantity = item["quantity"]
        discount = item["discount"]

        subtotal += price * quantity * (1 - discount / 100)

    return round(subtotal * (1 + tax_rate / 100), 2)
"""

    print("\n===== SKILLPROOF EVALUATION =====\n")

    evaluation = evaluate_solution(
        challenge=challenge,
        solution=solution,
        skill="Python",
    )

    print(evaluation)
