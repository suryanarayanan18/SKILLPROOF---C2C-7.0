"""Test Runner Service for SkillProof.

Executes user code against test cases with real execution via JDoodle,
detects compiler/runtime errors, and performs strict output validation
(disallowing fake PASS behavior).
"""

from __future__ import annotations

import html.parser
import re
from typing import Any

try:
    from schemas import TestCaseItem, TestCaseResult, TestRunResponse, TestStatus
    from services.jdoodle import execute_code
except (ImportError, ModuleNotFoundError):
    from backend.schemas import TestCaseItem, TestCaseResult, TestRunResponse, TestStatus
    from backend.services.jdoodle import execute_code



def normalize_output(text: str) -> str:
    """
    Normalize output string for comparison:
    - Normalizes CRLF to LF
    - Strips harmless trailing whitespace from each line
    - Strips leading and trailing newlines/whitespace
    """
    if not text:
        return ""
    lines = [line.rstrip() for line in text.replace("\r\n", "\n").split("\n")]
    return "\n".join(lines).strip()


class _HTMLSemanticValidator(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.tags: list[str] = []
        self.attrs: dict[str, list[dict[str, str]]] = {}
        self.has_doctype = False

    def handle_decl(self, decl: str) -> None:
        if "doctype" in decl.lower():
            self.has_doctype = True

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        t = tag.lower()
        self.tags.append(t)
        attr_dict = {k.lower(): (v or "") for k, v in attrs}
        self.attrs.setdefault(t, []).append(attr_dict)


def evaluate_html_code(code: str, test_cases: list[TestCaseItem]) -> list[TestCaseResult]:
    """
    Safely evaluate HTML code structure and semantics without faking console execution.
    """
    results: list[TestCaseResult] = []
    validator = _HTMLSemanticValidator()
    try:
        validator.feed(code)
    except Exception as exc:
        results.append(
            TestCaseResult(
                name="HTML Well-Formedness",
                input="Source Code",
                expected_output="Valid HTML Document",
                actual_output=f"Parser Error: {exc}",
                status="COMPILATION_ERROR",
                error=str(exc),
                execution_time_ms=1.0,
            )
        )
        return results

    if not test_cases:
        # Default baseline checks for HTML
        has_semantic = any(t in validator.tags for t in ("main", "header", "nav", "section", "article", "footer"))
        results.append(
            TestCaseResult(
                name="Semantic Elements Check",
                input="HTML Tags",
                expected_output="Includes semantic landmark elements (header, nav, main, section, footer)",
                actual_output="Found: " + ", ".join(set(validator.tags)),
                status="PASS" if has_semantic else "FAIL",
                error=None if has_semantic else "No semantic HTML landmarks detected.",
                execution_time_ms=2.0,
            )
        )
        return results

    for idx, tc in enumerate(test_cases, 1):
        name = tc.name or f"HTML Test {idx}"
        target = tc.input.strip() or tc.expected_output.strip()
        expected = tc.expected_output.strip() or tc.input.strip()

        # Check for specific tag or attribute requirement
        pass_test = False
        actual = ""

        if target.startswith("tag:"):
            req_tag = target.replace("tag:", "").strip().lower()
            pass_test = req_tag in validator.tags
            actual = f"Tag <{req_tag}> {'found' if pass_test else 'missing'}"
        elif target.startswith("<") and target.endswith(">"):
            req_tag = target.strip("<>/ ").lower()
            pass_test = req_tag in validator.tags
            actual = f"Tag <{req_tag}> {'found' if pass_test else 'missing'}"
        elif target.startswith("attr:"):
            parts = target.replace("attr:", "").strip().split("=", 1)
            req_attr = parts[0].strip().lower()
            req_val = parts[1].strip() if len(parts) > 1 else None
            # Scan attributes
            found = False
            for t, attr_list in validator.attrs.items():
                for a in attr_list:
                    if req_attr in a:
                        if req_val is None or a[req_attr] == req_val:
                            found = True
                            break
            pass_test = found
            actual = f"Attribute '{target}' {'present' if pass_test else 'absent'}"
        else:
            # Substring/regex presence in HTML source
            matched = bool(re.search(re.escape(target), code, re.IGNORECASE)) if target else True
            pass_test = matched
            actual = f"Pattern '{target}' {'matched' if pass_test else 'not matched'}"

        results.append(
            TestCaseResult(
                name=name,
                input=tc.input,
                expected_output=tc.expected_output,
                actual_output=actual,
                status="PASS" if pass_test else "FAIL",
                error=None if pass_test else f"Assertion failed: expected '{expected}', got '{actual}'",
                execution_time_ms=2.0,
            )
        )

    return results


def _build_execution_payload(code: str, language: str, test_input: str) -> tuple[str, str]:
    """
    Prepare script code and stdin for execution based on language and test input style.
    Handles both standard IO (reading from stdin) and function invocation tests.
    """
    lang = language.strip().lower()
    raw_input = test_input.strip()

    # If Python and the test input looks like an invocation expression
    # (e.g., function call or assignment) and code does not explicitly call input()
    if lang in ("python", "python3", "py"):
        if ("input(" not in code and "sys.stdin" not in code) and (
            raw_input.startswith("assert ")
            or "(" in raw_input
            or "=" in raw_input
            or raw_input.startswith("print(")
        ):
            # Wrap as test runner script
            harness = code + "\n\n# --- Test Harness Execution ---\n"
            if raw_input.startswith("print(") or raw_input.startswith("assert "):
                harness += raw_input + "\n"
            elif "=" in raw_input and ";" in raw_input:
                harness += raw_input + "\n"
            else:
                # Expression evaluation e.g. "process_cart(...)"
                harness += f"__test_result = {raw_input}\nif __test_result is not None:\n    print(__test_result)\n"
            return harness, ""

    # Default: Pass code as-is and supply test_input via stdin
    return code, test_input


def run_single_test(
    code: str,
    language: str,
    test_case: TestCaseItem,
) -> TestCaseResult:
    """
    Execute candidate code against a single test case.
    """
    script, stdin_data = _build_execution_payload(code, language, test_case.input)
    exec_res = execute_code(script, language=language, stdin=stdin_data)

    status = exec_res["status"]
    actual_output = exec_res["stdout"]
    time_ms = exec_res.get("execution_time_ms", 0.0)

    # 1. Compilation Error
    if status == "COMPILATION_ERROR" or exec_res.get("compiler_error"):
        err_msg = exec_res.get("compiler_error") or exec_res.get("stderr") or "Compilation failed"
        return TestCaseResult(
            name=test_case.name,
            input=test_case.input,
            expected_output=test_case.expected_output,
            actual_output=actual_output or err_msg,
            status="COMPILATION_ERROR",
            error=err_msg,
            execution_time_ms=time_ms,
        )

    # 2. Runtime Error
    if status == "RUNTIME_ERROR" or exec_res.get("runtime_error"):
        err_msg = exec_res.get("runtime_error") or exec_res.get("stderr") or "Runtime error"
        return TestCaseResult(
            name=test_case.name,
            input=test_case.input,
            expected_output=test_case.expected_output,
            actual_output=actual_output or err_msg,
            status="RUNTIME_ERROR",
            error=err_msg,
            execution_time_ms=time_ms,
        )

    # 3. Timeout
    if status == "TIMEOUT":
        err_msg = exec_res.get("runtime_error") or "Execution timed out."
        return TestCaseResult(
            name=test_case.name,
            input=test_case.input,
            expected_output=test_case.expected_output,
            actual_output=err_msg,
            status="TIMEOUT",
            error=err_msg,
            execution_time_ms=time_ms,
        )

    # 4. Other system error
    if status == "ERROR":
        err_msg = exec_res.get("stderr") or "Execution system error"
        return TestCaseResult(
            name=test_case.name,
            input=test_case.input,
            expected_output=test_case.expected_output,
            actual_output=err_msg,
            status="ERROR",
            error=err_msg,
            execution_time_ms=time_ms,
        )

    # 5. Output Comparison (Strict value checking, harmless whitespace ignored)
    norm_actual = normalize_output(actual_output)
    norm_expected = normalize_output(test_case.expected_output)

    # STRICT: empty expected_output means the test is misconfigured — never PASS
    if not norm_expected:
        return TestCaseResult(
            name=test_case.name,
            input=test_case.input,
            expected_output=test_case.expected_output,
            actual_output=actual_output,
            status="ERROR",
            error="Test case has no expected output defined — cannot evaluate. This is a challenge configuration error.",
            execution_time_ms=time_ms,
        )

    if norm_actual == norm_expected:
        test_status: TestStatus = "PASS"
        error = None
    else:
        test_status = "FAIL"
        error = f"Expected '{norm_expected}', but got '{norm_actual}'"

    return TestCaseResult(
        name=test_case.name,
        input=test_case.input,
        expected_output=test_case.expected_output,
        actual_output=actual_output,
        status=test_status,
        error=error,
        execution_time_ms=time_ms,
    )


def run_test_suite(
    code: str,
    language: str,
    test_cases: list[TestCaseItem],
    assessment_id: str | None = None,
) -> TestRunResponse:
    """
    Execute full test suite against candidate code.
    Evaluates each test case individually and aggregates total/passed/failed counts.
    """
    lang_clean = language.strip().lower()

    # Special handling for HTML
    if lang_clean in ("html", "html5"):
        test_results = evaluate_html_code(code, test_cases)
        passed = sum(1 for t in test_results if t.status == "PASS")
        failed = len(test_results) - passed
        overall_status: TestStatus = "PASS" if failed == 0 and len(test_results) > 0 else "FAIL"
        return TestRunResponse(
            assessment_id=assessment_id,
            skill="HTML",
            total=len(test_results),
            passed=passed,
            failed=failed,
            status=overall_status,
            tests=test_results,
            stdout="HTML DOM & semantic structure analyzed successfully.",
            compiler_error=None,
            runtime_error=None,
            execution_time_ms=sum(t.execution_time_ms for t in test_results),
            provider="sandbox-html",
        )

    # STRICT: No test cases = UNVERIFIED. Never fake a pass with a dummy test.
    if not test_cases:
        return TestRunResponse(
            assessment_id=assessment_id,
            skill=language,
            total=0,
            passed=0,
            failed=0,
            status="ERROR",
            tests=[],
            stdout="",
            compiler_error=None,
            runtime_error="No hidden test cases were defined for this challenge. Submission cannot be evaluated.",
            execution_time_ms=0.0,
            provider="none",
        )

    test_results: list[TestCaseResult] = []
    first_compiler_err: str | None = None
    first_runtime_err: str | None = None
    combined_stdout: list[str] = []
    total_time_ms: float = 0.0
    provider_used = "jdoodle"

    for tc in test_cases:
        res = run_single_test(code, language, tc)
        test_results.append(res)
        total_time_ms += res.execution_time_ms

        if res.status == "COMPILATION_ERROR" and not first_compiler_err:
            first_compiler_err = res.error
        elif res.status == "RUNTIME_ERROR" and not first_runtime_err:
            first_runtime_err = res.error

        if res.actual_output and res.status in ("PASS", "FAIL"):
            combined_stdout.append(f"[{res.name}] {res.actual_output}")

    passed_count = sum(1 for t in test_results if t.status == "PASS")
    failed_count = len(test_results) - passed_count

    if first_compiler_err:
        suite_status: TestStatus = "COMPILATION_ERROR"
    elif first_runtime_err:
        suite_status = "RUNTIME_ERROR"
    elif failed_count > 0:
        suite_status = "FAIL"
    else:
        suite_status = "PASS"

    return TestRunResponse(
        assessment_id=assessment_id,
        skill=language,
        total=len(test_results),
        passed=passed_count,
        failed=failed_count,
        status=suite_status,
        tests=test_results,
        stdout="\n".join(combined_stdout),
        compiler_error=first_compiler_err,
        runtime_error=first_runtime_err,
        execution_time_ms=round(total_time_ms, 2),
        provider=provider_used,
    )
