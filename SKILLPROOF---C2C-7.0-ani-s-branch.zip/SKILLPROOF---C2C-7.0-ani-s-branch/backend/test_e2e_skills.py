import requests

base = 'http://127.0.0.1:8000'

solutions = {
    'Python': 'def solution():\n    return sum(range(10))\n',
    'C++': '#include <iostream>\nint main() {\n    std::cout << 45 << std::endl;\n    return 0;\n}\n',
    'HTML': '<!DOCTYPE html>\n<html lang="en">\n<head><title>Test</title></head>\n<body>\n  <main>\n    <h1>Accessible Form</h1>\n    <form>\n      <label for="name">Name</label>\n      <input id="name" type="text" required />\n      <button type="submit">Submit</button>\n    </form>\n  </main>\n</body>\n</html>\n'
}

if __name__ == '__main__':
    for skill, sol in solutions.items():
        print(f"\n=== Testing {skill} End-to-End ===")
        r = requests.post(f"{base}/api/challenges", json={"skill": skill, "difficulty": "intermediate"}, timeout=90)
        assert r.status_code == 201, f"Challenge creation failed for {skill}: {r.text}"
        ch = r.json()
        ass_id = ch["assessment_id"]
        print(f"  [+] Challenge created: id={ass_id}, title={ch.get('title')}")
        print(f"  [+] Starter code preview: {repr(ch.get('starter_code', '')[:60])}")

        sub_res = requests.post(f"{base}/api/assessments/{ass_id}/submit", json={"solution": sol, "time_elapsed_seconds": 45}, timeout=90)
        assert sub_res.status_code == 200, f"Submission failed for {skill}: {sub_res.text}"
        eval_data = sub_res.json().get("evaluation", {})
        print(f"  [+] Evaluated: score={eval_data.get('overall_score')}, summary={repr(eval_data.get('summary', '')[:60])}")

    p = requests.get(f"{base}/api/passport", timeout=10)
    print(f"\n=== Passport status: {p.status_code} ===")
    if p.status_code == 200:
        print(f"  [+] Passport skill: {p.json().get('skill')}, score: {p.json().get('overall_score')}")
    print("\n>>> ALL THREE SKILLS (PYTHON, C++, HTML) COMPLETED END-TO-END SUCCESSFULLY <<<")

