import unittest
from unittest.mock import patch
from services.gemini import generate_challenge, evaluate_solution, generate_text


class GeminiServiceTests(unittest.TestCase):
    @patch("services.gemini.generate_text", return_value='{"title": "C++ Memory Safety"}')
    def test_cpp_challenge_generation_prompt(self, mock_gen):
        res = generate_challenge(skill="C++", difficulty="intermediate")
        self.assertEqual(res, '{"title": "C++ Memory Safety"}')
        call_prompt = mock_gen.call_args[0][0]
        self.assertIn("Skill:\nC++", call_prompt)
        self.assertIn("For a C++ challenge", call_prompt)
        self.assertIn("STL", call_prompt)
        self.assertIn("#include <iostream>", call_prompt)

    @patch("services.gemini.generate_text", return_value='{"title": "HTML Semantic Form"}')
    def test_html_challenge_generation_prompt(self, mock_gen):
        res = generate_challenge(skill="HTML", difficulty="beginner")
        self.assertEqual(res, '{"title": "HTML Semantic Form"}')
        call_prompt = mock_gen.call_args[0][0]
        self.assertIn("Skill:\nHTML", call_prompt)
        self.assertIn("For an HTML challenge", call_prompt)
        self.assertIn("semantic, accessible HTML", call_prompt)

    @patch("services.gemini.generate_text", return_value='{"overall_score": 90}')
    def test_cpp_evaluation_prompt(self, mock_gen):
        res = evaluate_solution(challenge="C++ Task", solution="#include <vector>", skill="C++")
        self.assertEqual(res, '{"overall_score": 90}')
        call_prompt = mock_gen.call_args[0][0]
        self.assertIn("C++ Evaluation Focus", call_prompt)
        self.assertIn("Memory safety", call_prompt)

    @patch("services.gemini.generate_text", return_value='{"overall_score": 95}')
    def test_html_evaluation_prompt(self, mock_gen):
        res = evaluate_solution(challenge="HTML Task", solution="<main></main>", skill="HTML")
        self.assertEqual(res, '{"overall_score": 95}')
        call_prompt = mock_gen.call_args[0][0]
        self.assertIn("HTML Evaluation Focus", call_prompt)
        self.assertIn("Semantic markup", call_prompt)


def run_live_check() -> None:
	prompt = """
You are testing the SkillProof AI system.

Respond with exactly:
SkillProof Gemini connection successful.
	"""
	result = generate_text(prompt)
	print(result)


if __name__ == "__main__":
    unittest.main()