"""Pydantic contracts for the SkillProof prototype API."""

from typing import Literal

from pydantic import BaseModel, Field, field_validator


Difficulty = Literal["beginner", "intermediate", "advanced"]
Skill = str


class ChallengeCreateRequest(BaseModel):
    skill: str = Field(min_length=1, max_length=100, examples=["Python"])
    difficulty: Difficulty = Field(default="intermediate")
    previous_performance: str | None = Field(default=None, max_length=4000)
    target_weakness: str | None = Field(default=None, max_length=1000)

    @field_validator("skill", mode="before")
    @classmethod
    def validate_skill(cls, value: str) -> str:
        if not value or not str(value).strip():
            raise ValueError("Skill cannot be empty.")
        cleaned = str(value).strip()
        lower = cleaned.lower()
        mapping: dict[str, str] = {
            "python": "Python",
            "javascript": "JavaScript",
            "js": "JavaScript",
            "c++": "C++",
            "cpp": "C++",
            "c plus plus": "C++",
            "html": "HTML",
            "html5": "HTML",
        }
        if lower in mapping:
            return mapping[lower]
        raise ValueError(f"Unsupported skill: {value}. Supported skills are Python, JavaScript, C++, HTML.")

    @field_validator("difficulty", mode="before")
    @classmethod
    def validate_difficulty(cls, value: str) -> Difficulty:
        if not value or not str(value).strip():
            raise ValueError("Difficulty cannot be empty.")
        cleaned = str(value).strip().lower()
        if cleaned in ("beginner", "intermediate", "advanced"):
            return cleaned  # type: ignore[return-value]
        raise ValueError(f"Unsupported difficulty: {value}. Supported difficulties are beginner, intermediate, advanced.")


class HiddenTestCase(BaseModel):
    name: str = "Hidden Test"
    input: str = ""
    expected_output: str = ""
    category: Literal["normal", "boundary", "edge_case"] = "normal"


class SessionAttempt(BaseModel):
    attempt_number: int
    timestamp: float
    status: str
    passed_tests: int
    total_tests: int
    failed_tests: int
    compilation_error: str | None = None
    runtime_error: str | None = None
    time_elapsed_seconds: int = 0


class ChallengeSession(BaseModel):
    assessment_id: str
    challenge_id: str
    skill: str
    difficulty: str
    submission_count: int = 0
    failed_submissions: int = 0
    passed_submissions: int = 0
    compilation_errors: int = 0
    runtime_errors: int = 0
    test_case_failures: int = 0
    retries: int = 0
    improvement_demonstrated: bool = False
    attempts: list[SessionAttempt] = Field(default_factory=list)


class ChallengeResponse(BaseModel):
    assessment_id: str
    challenge_id: str
    skill: Skill | str
    difficulty: Difficulty
    title: str
    overview: str
    task: str
    constraints: list[str]
    starter_code: str
    examples: list[dict[str, str]] = Field(default_factory=list)


class SolutionSubmitRequest(BaseModel):
    solution: str = Field(min_length=1, max_length=100_000)
    time_elapsed_seconds: int | None = Field(default=None, ge=0)


class EvaluationRequest(SolutionSubmitRequest):
    assessment_id: str = Field(min_length=1)


class EvaluationResponse(BaseModel):
    overall_score: int = Field(ge=0, le=100)
    correctness: int = Field(ge=0, le=100)
    problem_solving: int = Field(ge=0, le=100)
    code_quality: int = Field(ge=0, le=100)
    efficiency: int = Field(ge=0, le=100)
    understanding: int = Field(ge=0, le=100)
    practical_application: int = Field(ge=0, le=100)
    summary: str
    strengths: list[str]
    weaknesses: list[str]
    feedback: str
    recommended_next_step: str
    status: Literal["completed"] = "completed"
    passed_tests: int = Field(default=0, ge=0)
    total_tests: int = Field(default=0, ge=0)
    failed_tests: int = Field(default=0, ge=0)
    hidden_tests_passed: int = Field(default=0, ge=0)
    hidden_tests_total: int = Field(default=3, ge=0)
    session_retries: int = Field(default=0, ge=0)
    session_submission_count: int = Field(default=1, ge=1)
    improvement_demonstrated: bool = False
    competency: str = "Developing"
    improvements: list[str] = Field(default_factory=list)
    next_difficulty: Difficulty | None = None
    test_results: list[dict[str, str]] = Field(default_factory=list)


class AssessmentResponse(ChallengeResponse):
    evaluation: EvaluationResponse | None = None
    submitted_solution: str | None = None
    time_elapsed_seconds: int | None = None


class AssessmentRecord(AssessmentResponse):
    hidden_tests: list[HiddenTestCase] = Field(default_factory=list)
    session: ChallengeSession | None = None


class HealthResponse(BaseModel):
    status: Literal["ok"]
    service: str
    provider: Literal["mock", "gemini", "nemotron"]
    has_gemini_key: bool = False
    has_nemotron_key: bool = False


class PassportResponse(BaseModel):
    assessment_id: str
    skill: Skill | str
    difficulty: Difficulty
    overall_score: int
    verified: bool
    summary: str


ExecutionStatus = Literal["SUCCESS", "COMPILATION_ERROR", "RUNTIME_ERROR", "TIMEOUT", "ERROR"]
TestStatus = Literal["PASS", "FAIL", "COMPILATION_ERROR", "RUNTIME_ERROR", "TIMEOUT", "ERROR"]


class ExecutionRequest(BaseModel):
    code: str = Field(min_length=1, max_length=100_000)
    language: str = Field(default="python", max_length=50)
    stdin: str = Field(default="", max_length=50_000)


class ExecutionResponse(BaseModel):
    stdout: str = ""
    stderr: str = ""
    compiler_error: str | None = None
    runtime_error: str | None = None
    status: ExecutionStatus = "SUCCESS"
    exit_code: int = 0
    execution_time_ms: float = 0.0
    memory: str | None = None
    provider: str = "jdoodle"
    is_html: bool = False


class TestCaseItem(BaseModel):
    name: str = "Test Case"
    input: str = ""
    expected_output: str = ""


class TestCaseResult(BaseModel):
    name: str
    input: str = ""
    expected_output: str = ""
    actual_output: str = ""
    status: TestStatus = "PASS"
    error: str | None = None
    execution_time_ms: float = 0.0


class TestRunRequest(BaseModel):
    assessment_id: str | None = None
    code: str = Field(min_length=1, max_length=100_000)
    language: str = Field(default="python", max_length=50)
    stdin: str = Field(default="", max_length=50_000)
    custom_tests: list[TestCaseItem] = Field(default_factory=list)
    tests: list[TestCaseItem] = Field(default_factory=list)


class TestRunResponse(BaseModel):
    assessment_id: str | None = None
    skill: str = "Python"
    total: int = 0
    passed: int = 0
    failed: int = 0
    status: TestStatus = "PASS"
    tests: list[TestCaseResult] = Field(default_factory=list)
    stdout: str = ""
    compiler_error: str | None = None
    runtime_error: str | None = None
    execution_time_ms: float = 0.0
    provider: str = "jdoodle"


class JDoodleConfigRequest(BaseModel):
    client_id: str = Field(default="")
    client_secret: str = Field(default="")

    def __init__(self, **data):
        if "clientId" in data and "client_id" not in data:
            data["client_id"] = data["clientId"]
        if "clientSecret" in data and "client_secret" not in data:
            data["client_secret"] = data["clientSecret"]
        super().__init__(**data)


class JDoodleStatusResponse(BaseModel):
    configured: bool
    has_client_id: bool
    has_client_secret: bool
    provider: str = "jdoodle"

