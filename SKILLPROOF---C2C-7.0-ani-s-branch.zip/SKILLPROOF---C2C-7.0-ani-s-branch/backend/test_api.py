import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

# Ensure backend directory is in sys.path
_backend_dir = str(Path(__file__).resolve().parent)
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)

from fastapi.testclient import TestClient

from app import ASSESSMENTS, app


CHALLENGE_TEXT = """TITLE:
Record Counter

PROBLEM:
Count valid records in a list.

TASK:
Write count_records(records).

CONSTRAINTS:
- Use one pass
- Return an integer

STARTER_CODE:
def count_records(records):
    pass
"""

EVALUATION_TEXT = """OVERALL SCORE:
85

CORRECTNESS:
90

PROBLEM SOLVING:
84

CODE QUALITY:
80

EFFICIENCY:
88

UNDERSTANDING:
86

PRACTICAL APPLICATION:
82

STRENGTHS:
- Correct one-pass solution

WEAKNESSES:
- Add more tests

FEEDBACK:
Clear and correct.

RECOMMENDED NEXT STEP:
Practice edge cases.
"""


class SkillProofApiTests(unittest.TestCase):
    def setUp(self):
        ASSESSMENTS.clear()
        self.client = TestClient(app)

    def test_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ok")
        self.assertEqual(response.json()["provider"], "nemotron")
        self.assertTrue("has_nemotron_key" in response.json())

    def test_frontend_static_mount(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Proof, Not Paper.", response.text)
        index = self.client.get("/index.html")
        self.assertEqual(index.status_code, 200)
        self.assertEqual(index.text, response.text)
        self.assertEqual(self.client.get("/js/flow.js").status_code, 200)
        route_aliases = [
            "/skill-selection", "/skill-selection.html",
            "/difficulty-selection", "/difficulty-selection.html",
            "/assessment-setup", "/assessment-setup.html",
            "/workspace", "/workspace.html",
            "/evaluation", "/evaluation.html",
            "/passport", "/passport.html", "/skill-passport",
            "/home", "/hub", "/hub.html", "/assessments",
            "/history", "/history.html", "/assessments-history",
            "/ai-analysis", "/ai-analysis.html",
            "/console", "/console.html",
        ]
        for route in route_aliases:
            res = self.client.get(route)
            self.assertEqual(res.status_code, 200, f"Route {route} failed with {res.status_code}")

    def test_challenge_request_validation(self):
        response = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "expert"})
        self.assertEqual(response.status_code, 422)
        ruby = self.client.post("/api/challenges", json={"skill": "Ruby", "difficulty": "beginner"})
        self.assertEqual(ruby.status_code, 422)

    @patch("services.nemotron.generate_text", return_value=CHALLENGE_TEXT)
    def test_create_challenge_and_submit_solution_via_nemotron(self, mock_nemotron):
        create = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "beginner"})
        self.assertEqual(create.status_code, 201)
        body = create.json()
        self.assertEqual(body["title"], "Record Counter")
        self.assertEqual(body["constraints"], ["Use one pass", "Return an integer"])
        mock_nemotron.assert_called_once()

        mock_nemotron.return_value = EVALUATION_TEXT
        submit = self.client.post(
            f"/api/assessments/{body['assessment_id']}/submit",
            json={"solution": "def count_records(records): return len(records)", "time_elapsed_seconds": 12},
        )
        self.assertEqual(submit.status_code, 200)
        self.assertEqual(submit.json()["evaluation"]["efficiency"], 88)
        self.assertEqual(submit.json()["evaluation"]["overall_score"], 85)

        passport = self.client.get("/api/passport")
        self.assertEqual(passport.status_code, 200)
        self.assertEqual(passport.json()["assessment_id"], body["assessment_id"])
        self.assertTrue(passport.json()["verified"])

    @patch("services.nemotron.generate_text", return_value=CHALLENGE_TEXT)
    def test_create_challenges_for_all_supported_skills(self, mock_nemotron):
        for skill in ["Python", "JavaScript", "C++", "HTML"]:
            res = self.client.post("/api/challenges", json={"skill": skill, "difficulty": "intermediate"})
            self.assertEqual(res.status_code, 201, f"Failed for {skill}")
            self.assertEqual(res.json()["skill"], skill)

    def test_unknown_assessment(self):
        response = self.client.get("/api/assessments/does-not-exist")
        self.assertEqual(response.status_code, 404)

    def test_passport_not_found_without_completed_assessment(self):
        response = self.client.get("/api/passport")
        self.assertEqual(response.status_code, 404)

    @patch("services.nemotron.generate_text", return_value=CHALLENGE_TEXT)
    def test_get_stored_assessment(self, mock_nemotron):
        create = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "beginner"})
        assessment_id = create.json()["assessment_id"]
        stored = self.client.get(f"/api/assessments/{assessment_id}")
        self.assertEqual(stored.status_code, 200)
        self.assertEqual(stored.json()["task"], "Write count_records(records).")

    def test_submission_validation(self):
        response = self.client.post("/api/assessments/does-not-exist/submit", json={"solution": ""})
        self.assertEqual(response.status_code, 422)

    @patch("services.nemotron.generate_text", side_effect=RuntimeError("NVIDIA_API_KEY is not set."))
    def test_missing_nemotron_key_returns_503(self, mock_nemotron):
        response = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "beginner"})
        self.assertEqual(response.status_code, 503)
        self.assertIn("NVIDIA Nemotron API key is not configured", response.json()["detail"])

    @patch("services.nemotron.generate_text", side_effect=RuntimeError("429 RESOURCE_EXHAUSTED"))
    def test_nemotron_quota_error_returns_429(self, mock_nemotron):
        response = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "advanced"})
        self.assertEqual(response.status_code, 429)
        self.assertIn("NVIDIA Nemotron API limit reached", response.json()["detail"])

    @patch("services.nemotron.generate_text", side_effect=RuntimeError("Connection reset by peer"))
    def test_nemotron_network_error_returns_502(self, mock_nemotron):
        response = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "beginner"})
        self.assertEqual(response.status_code, 502)
        self.assertIn("NVIDIA Nemotron live API error", response.json()["detail"])

    @patch("services.nemotron.generate_text")
    def test_evaluation_failure_returns_nemotron_error(self, mock_nemotron):
        mock_nemotron.return_value = CHALLENGE_TEXT
        assessment = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "beginner"}).json()
        mock_nemotron.side_effect = RuntimeError("429 RESOURCE_EXHAUSTED")
        response = self.client.post(
            f"/api/assessments/{assessment['assessment_id']}/submit",
            json={"solution": "def test(): pass"},
        )
        self.assertEqual(response.status_code, 429)
        self.assertIn("NVIDIA Nemotron API limit reached", response.json()["detail"])


    @patch("services.nemotron.generate_text")
    def test_cpp_full_flow(self, mock_nemotron):
        cpp_challenge = """TITLE:
Safe Memory Vector
OVERVIEW:
Implement a thread-safe circular buffer in C++.
TASK:
Write class CircularBuffer with push and pop.
CONSTRAINTS:
- Use std::vector
- Ensure exception safety
STARTER_CODE:
#include <iostream>
#include <vector>

class CircularBuffer {
public:
    void push(int val);
    int pop();
};
"""
        cpp_evaluation = """OVERALL SCORE:
92
CORRECTNESS:
95
PROBLEM SOLVING:
90
CODE QUALITY:
92
EFFICIENCY:
94
UNDERSTANDING:
90
PRACTICAL APPLICATION:
91
STRENGTHS:
- Excellent RAII and STL usage
WEAKNESSES:
- Add benchmark for high concurrency
FEEDBACK:
Strong modern C++20 implementation.
RECOMMENDED NEXT STEP:
Explore lock-free queues.
"""
        mock_nemotron.return_value = cpp_challenge
        create = self.client.post("/api/challenges", json={"skill": "C++", "difficulty": "advanced"})
        self.assertEqual(create.status_code, 201)
        data = create.json()
        self.assertEqual(data["skill"], "C++")
        self.assertIn("#include <iostream>", data["starter_code"])

        # Also test alias normalization
        alias_res = self.client.post("/api/challenges", json={"skill": "cpp", "difficulty": "intermediate"})
        self.assertEqual(alias_res.status_code, 201)
        self.assertEqual(alias_res.json()["skill"], "C++")

        # Submit solution
        mock_nemotron.return_value = cpp_evaluation
        submit = self.client.post(
            f"/api/assessments/{data['assessment_id']}/submit",
            json={"solution": "#include <vector>\n// implementation here", "time_elapsed_seconds": 180},
        )
        self.assertEqual(submit.status_code, 200)
        eval_data = submit.json()["evaluation"]
        self.assertEqual(eval_data["overall_score"], 92)

        passport = self.client.get("/api/passport")
        self.assertEqual(passport.status_code, 200)
        self.assertEqual(passport.json()["skill"], "C++")
        self.assertTrue(passport.json()["verified"])

    @patch("services.nemotron.generate_text")
    def test_html_full_flow(self, mock_nemotron):
        html_challenge = """TITLE:
Accessible Registration Form
OVERVIEW:
Construct a semantic and accessible user registration form in HTML5.
TASK:
Create a semantic form with appropriate input types, labels, and fieldset.
CONSTRAINTS:
- Use semantic elements <form>, <fieldset>, <legend>, <label>
- Associate labels with inputs via for/id
STARTER_CODE:
<!DOCTYPE html>
<html lang="en">
<head><title>Form</title></head>
<body>
  <!-- Semantic form -->
</body>
</html>
"""
        html_evaluation = """OVERALL SCORE:
88
CORRECTNESS:
90
PROBLEM SOLVING:
86
CODE QUALITY:
88
EFFICIENCY:
85
UNDERSTANDING:
90
PRACTICAL APPLICATION:
89
STRENGTHS:
- Proper label associations and landmark elements
WEAKNESSES:
- Add aria-describedby for error help text
FEEDBACK:
Clean W3C compliant semantic markup.
RECOMMENDED NEXT STEP:
Explore complex ARIA combobox widgets.
"""
        mock_nemotron.return_value = html_challenge
        create = self.client.post("/api/challenges", json={"skill": "HTML", "difficulty": "intermediate"})
        self.assertEqual(create.status_code, 201)
        data = create.json()
        self.assertEqual(data["skill"], "HTML")
        self.assertIn("<!DOCTYPE html>", data["starter_code"])

        # Also test alias normalization
        alias_res = self.client.post("/api/challenges", json={"skill": "html5", "difficulty": "beginner"})
        self.assertEqual(alias_res.status_code, 201)
        self.assertEqual(alias_res.json()["skill"], "HTML")

        # Submit solution
        mock_nemotron.return_value = html_evaluation
        submit = self.client.post(
            f"/api/assessments/{data['assessment_id']}/submit",
            json={"solution": "<form><label for='name'>Name</label><input id='name'/></form>", "time_elapsed_seconds": 90},
        )
        self.assertEqual(submit.status_code, 200)
        eval_data = submit.json()["evaluation"]
        self.assertEqual(eval_data["overall_score"], 88)

        passport = self.client.get("/api/passport")
        self.assertEqual(passport.status_code, 200)
        self.assertEqual(passport.json()["skill"], "HTML")
        self.assertTrue(passport.json()["verified"])

    def test_jdoodle_status_and_config(self):
        status_res = self.client.get("/api/jdoodle/status")
        self.assertEqual(status_res.status_code, 200)
        self.assertIn("configured", status_res.json())

        config_res = self.client.post(
            "/api/config/jdoodle",
            json={"clientId": "test-client-id", "clientSecret": "test-client-secret"},
        )
        self.assertEqual(config_res.status_code, 200)
        self.assertTrue(config_res.json()["configured"])

    def test_execute_code_raw_python(self):
        res = self.client.post(
            "/api/execute",
            json={"code": "print(sum([1, 2, 3, 4]))", "language": "python", "stdin": ""},
        )
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertEqual(body["status"], "SUCCESS")
        self.assertEqual(body["stdout"].strip(), "10")
        self.assertEqual(body["exit_code"], 0)

    def test_execute_code_with_stdin(self):
        res = self.client.post(
            "/api/execute",
            json={
                "code": "import sys\nname = sys.stdin.read().strip()\nprint(f'Hello {name}')",
                "language": "python",
                "stdin": "SkillProof Engineer",
            },
        )
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertEqual(body["status"], "SUCCESS")
        self.assertEqual(body["stdout"].strip(), "Hello SkillProof Engineer")

    def test_execute_code_syntax_error(self):
        res = self.client.post(
            "/api/execute",
            json={"code": "def syntax_err(\n    return 42", "language": "python", "stdin": ""},
        )
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertIn(body["status"], ["COMPILATION_ERROR", "RUNTIME_ERROR"])
        err = body.get("compiler_error") or body.get("runtime_error") or ""
        self.assertTrue("SyntaxError" in err or len(err) > 0)

    def test_run_test_suite_strict_pass_and_fail(self):
        """Verifies that tests only PASS on exact normalized match, and strictly FAIL otherwise."""
        payload = {
            "code": "def add(a, b):\n    return a + b",
            "language": "python",
            "custom_tests": [
                {
                    "name": "Correct Addition",
                    "input": "print(add(2, 3))",
                    "expected_output": "5",
                },
                {
                    "name": "Intentional Failure",
                    "input": "print(add(2, 3))",
                    "expected_output": "99",
                },
            ],
        }
        res = self.client.post("/api/tests/run", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["total"], 2)
        self.assertEqual(data["passed"], 1)
        self.assertEqual(data["failed"], 1)
        self.assertEqual(data["status"], "FAIL")

        t1 = data["tests"][0]
        self.assertEqual(t1["name"], "Correct Addition")
        self.assertEqual(t1["status"], "PASS")
        self.assertIsNone(t1.get("error"))

        t2 = data["tests"][1]
        self.assertEqual(t2["name"], "Intentional Failure")
        self.assertEqual(t2["status"], "FAIL")
        self.assertIn("Expected '99', but got '5'", t2["error"])

    def test_run_test_suite_html_validation(self):
        payload = {
            "code": "<!DOCTYPE html><main><header><h1>Header</h1></header><section><p>Test</p></section></main>",
            "language": "html",
            "custom_tests": [
                {
                    "name": "Main Landmark",
                    "input": "tag:main",
                    "expected_output": "Tag <main> found",
                },
                {
                    "name": "Article Missing",
                    "input": "tag:article",
                    "expected_output": "Tag <article> found",
                },
            ],
        }
        res = self.client.post("/api/tests/run", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["total"], 2)
        self.assertEqual(data["passed"], 1)
        self.assertEqual(data["failed"], 1)
        self.assertEqual(data["tests"][0]["status"], "PASS")
        self.assertEqual(data["tests"][1]["status"], "FAIL")


    def test_demo_mode_fallback_without_keys(self):
        old_nv = os.environ.pop("NVIDIA_API_KEY", None)
        old_gem = os.environ.pop("GEMINI_API_KEY", None)
        try:
            # Without key and without demo mode -> 503
            res_fail = self.client.post("/api/challenges", json={"skill": "Python", "difficulty": "intermediate"})
            self.assertEqual(res_fail.status_code, 503)

            # With demo mode header -> 201 Created with 3 hidden tests
            res_demo = self.client.post(
                "/api/challenges",
                json={"skill": "Python", "difficulty": "intermediate"},
                headers={"X-Demo-Mode": "true"},
            )
            self.assertEqual(res_demo.status_code, 201)
            data = res_demo.json()
            self.assertEqual(data["skill"], "Python")
            self.assertIn("def ", data["starter_code"])
            assessment_id = data["assessment_id"]

            # Stored assessment contains 3 hidden tests
            stored = self.client.get(f"/api/assessments/{assessment_id}")
            self.assertEqual(stored.status_code, 200)

            # Submit with demo mode header -> succeeds and produces evaluation
            sub_res = self.client.post(
                f"/api/assessments/{assessment_id}/submit",
                json={"solution": "def aggregate_payload_stream(events, window_seconds=60):\n    return {}\n", "time_elapsed_seconds": 30},
                headers={"X-Demo-Mode": "true"},
            )
            self.assertEqual(sub_res.status_code, 200)
            sub_data = sub_res.json()
            self.assertIn("evaluation", sub_data)
            self.assertGreaterEqual(sub_data["evaluation"]["overall_score"], 0)
        finally:
            if old_nv is not None:
                os.environ["NVIDIA_API_KEY"] = old_nv
            if old_gem is not None:
                os.environ["GEMINI_API_KEY"] = old_gem


if __name__ == "__main__":
    unittest.main()



