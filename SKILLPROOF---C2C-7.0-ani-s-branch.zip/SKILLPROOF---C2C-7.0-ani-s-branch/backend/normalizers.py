"""Normalize the existing line-oriented Gemini responses for API clients."""

from __future__ import annotations

import json
import re

try:
    from schemas import ChallengeResponse, EvaluationResponse, HiddenTestCase
except (ImportError, ModuleNotFoundError):
    from backend.schemas import ChallengeResponse, EvaluationResponse, HiddenTestCase


SECTION_PATTERN = re.compile(r"^([A-Z][A-Z _/]+):\s*$", re.MULTILINE)


def _sections(text: str) -> dict[str, str]:
    """Parse the documented `SECTION:` format without trusting it completely."""
    matches = list(SECTION_PATTERN.finditer(text or ""))
    result: dict[str, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        result[match.group(1).strip()] = text[match.end() : end].strip()
    return result


def _json_object(text: str) -> dict[str, object]:
    """Extract a JSON object from plain text, fenced markdown, or reasoning output."""
    candidate = (text or "").strip()
    if not candidate:
        return {}

    # Strip any reasoning tags if present
    candidate = re.sub(r"<think>.*?</think>", "", candidate, flags=re.DOTALL).strip()

    # If wrapped in markdown code blocks
    code_block = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", candidate, flags=re.IGNORECASE)
    if code_block:
        try:
            value = json.loads(code_block.group(1).strip())
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass

    # Direct parse or slice outermost { ... }
    start, end = candidate.find("{"), candidate.rfind("}")
    candidates = [candidate]
    if start >= 0 and end > start:
        candidates.insert(0, candidate[start : end + 1])

    for item in candidates:
        try:
            value = json.loads(item)
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            try:
                # Remove trailing commas before closing braces/brackets
                sanitized = re.sub(r",\s*([\]}])", r"\1", item)
                value = json.loads(sanitized)
                if isinstance(value, dict):
                    return value
            except Exception:
                continue
    return {}


def _lines(value: str) -> list[str]:
    return [line.strip().lstrip("-• ").strip() for line in value.splitlines() if line.strip().lstrip("-• ").strip()]


def _score(sections: dict[str, str], key: str, default: int) -> int:
    match = re.search(r"\d{1,3}", sections.get(key, ""))
    return min(100, max(0, int(match.group()))) if match else default




def normalize_challenge(
    text: str, *, assessment_id: str, challenge_id: str, skill: str, difficulty: str
) -> tuple[ChallengeResponse, list[HiddenTestCase]]:
    data = _json_object(text)
    sections = _sections(text)
    problem = str(data.get("overview") or sections.get("PROBLEM", ""))
    task = str(data.get("task") or sections.get("TASK", "")) or problem or text.strip()
    overview = problem or task or f"A {difficulty} {skill} practical assessment."
    raw_constraints = data.get("constraints")
    constraints = [str(item).strip() for item in raw_constraints if str(item).strip()] if isinstance(raw_constraints, list) else _lines(sections.get("CONSTRAINTS", ""))
    raw_examples = data.get("examples")
    examples = [
        {"input": str(item.get("input", "")), "output": str(item.get("output", ""))}
        for item in raw_examples if isinstance(item, dict)
    ] if isinstance(raw_examples, list) else []
    starter = str(data.get("starter_code") or sections.get("STARTER_CODE", "")).strip()
    if not starter:
        sk = skill.strip().lower()
        if sk in ("c++", "cpp"):
            starter = "#include <iostream>\n#include <vector>\n#include <string>\n\n// Write your solution here\nint main() {\n    return 0;\n}\n"
        elif sk in ("html", "html5"):
            starter = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <title>Assessment</title>\n</head>\n<body>\n  <!-- Write your semantic HTML here -->\n</body>\n</html>"
        elif sk in ("javascript", "js"):
            starter = "// Write your solution here\nfunction solution() {\n  \n}\n"
        else:
            starter = "# Write your solution here\ndef solution():\n    pass\n"

    # Extract exactly 3 hidden tests
    raw_hidden = data.get("hidden_tests")
    hidden_tests: list[HiddenTestCase] = []
    if isinstance(raw_hidden, list):
        for item in raw_hidden:
            if isinstance(item, dict) and (item.get("input") or item.get("expected_output") or item.get("output")):
                hidden_tests.append(
                    HiddenTestCase(
                        name=str(item.get("name") or f"Hidden Test {len(hidden_tests) + 1}"),
                        input=str(item.get("input", "")),
                        expected_output=str(item.get("expected_output", item.get("output", ""))),
                        category=item.get("category", "normal") if item.get("category") in ("normal", "boundary", "edge_case") else "normal",
                    )
                )

    # STRICT: Reject any challenge with fewer than 3 valid hidden tests.
    # A valid hidden test must have BOTH a non-empty input AND non-empty expected_output.
    # Supplementing from examples is NOT allowed (examples are visible to the user).
    valid_hidden = [ht for ht in hidden_tests if ht.input.strip() and ht.expected_output.strip()]

    if len(valid_hidden) < 3:
        raise ValueError(
            f"Challenge generation produced only {len(valid_hidden)} valid hidden test case(s) "
            f"(need exactly 3 with non-empty input AND expected_output). "
            f"Challenge rejected to prevent fake evaluation."
        )

    hidden_tests = valid_hidden[:3]


    response = ChallengeResponse(
        assessment_id=assessment_id,
        challenge_id=challenge_id,
        skill=skill,
        difficulty=difficulty,
        title=str(data.get("title") or sections.get("TITLE", "").splitlines()[0].strip() or f"{skill} practical challenge"),
        overview=overview,
        task=task or "Complete the generated assessment task.",
        constraints=constraints,
        starter_code=starter,
        examples=examples,
    )
    return response, hidden_tests


def normalize_evaluation(text: str) -> EvaluationResponse:
    data = _json_object(text)
    sections = _sections(text)
    def score(key: str, heading: str, default: int) -> int:
        value = data.get(key)
        if isinstance(value, (int, float)):
            return min(100, max(0, int(value)))
        if isinstance(value, str) and re.fullmatch(r"\s*\d{1,3}\s*", value):
            return min(100, max(0, int(value)))
        return _score(sections, heading, default)
    correctness = score("correctness", "CORRECTNESS", 0)
    problem_solving = score("problem_solving", "PROBLEM SOLVING", 0)
    code_quality = score("code_quality", "CODE QUALITY", 0)
    understanding = score("understanding", "UNDERSTANDING", 0)
    efficiency = score("efficiency", "EFFICIENCY", round((correctness + problem_solving) / 2))
    practical_application = score(
        "practical_application", "PRACTICAL APPLICATION", round((correctness + understanding) / 2)
    )
    overall = score(
        "overall_score", "OVERALL SCORE",
        round((correctness + problem_solving + code_quality + efficiency + understanding + practical_application) / 6),
    )
    return EvaluationResponse(
        overall_score=overall,
        correctness=correctness,
        problem_solving=problem_solving,
        code_quality=code_quality,
        efficiency=efficiency,
        understanding=understanding,
        practical_application=practical_application,
        summary=str(data.get("summary") or sections.get("FEEDBACK", "").strip() or "Evaluation completed."),
        strengths=[str(item) for item in data.get("strengths", [])] if isinstance(data.get("strengths"), list) else _lines(sections.get("STRENGTHS", "")),
        weaknesses=[str(item) for item in data.get("weaknesses", [])] if isinstance(data.get("weaknesses"), list) else _lines(sections.get("WEAKNESSES", "")),
        feedback=str(data.get("feedback") or sections.get("FEEDBACK", "").strip() or "The evaluator did not provide written feedback."),
        recommended_next_step=str(
            data.get("recommended_next_step")
            or sections.get("RECOMMENDED NEXT STEP", "").strip()
            or "Review the challenge requirements and retry with additional edge cases."
        ),
        status="completed",
        passed_tests=max(0, int(data.get("passed_tests", 0))) if str(data.get("passed_tests", "")).isdigit() else 0,
        total_tests=max(0, int(data.get("total_tests", 0))) if str(data.get("total_tests", "")).isdigit() else 0,
        failed_tests=max(0, int(data.get("failed_tests", 0))) if str(data.get("failed_tests", "")).isdigit() else 0,
        hidden_tests_passed=max(0, int(data.get("hidden_tests_passed", 0))) if str(data.get("hidden_tests_passed", "")).isdigit() else 0,
        hidden_tests_total=max(3, int(data.get("hidden_tests_total", 3))) if str(data.get("hidden_tests_total", "")).isdigit() else 3,
        session_retries=max(0, int(data.get("session_retries", 0))) if str(data.get("session_retries", "")).isdigit() else 0,
        session_submission_count=max(1, int(data.get("session_submission_count", 1))) if str(data.get("session_submission_count", "")).isdigit() else 1,
        improvement_demonstrated=bool(data.get("improvement_demonstrated", False)),
        competency=str(data.get("competency") or "Developing"),
        improvements=[str(item) for item in data.get("improvements", [])] if isinstance(data.get("improvements"), list) else [],
        next_difficulty=str(data["next_difficulty"]) if data.get("next_difficulty") in {"beginner", "intermediate", "advanced"} else None,
        test_results=[
            {"name": str(item.get("name", "Test")), "status": str(item.get("status", "FAIL")), "detail": str(item.get("detail", ""))}
            for item in data.get("test_results", []) if isinstance(item, dict)
        ] if isinstance(data.get("test_results"), list) else [],
    )
