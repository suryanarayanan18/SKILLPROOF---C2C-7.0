# SkillProof Server Runner
# Frees port 8000 if already occupied, then starts Uvicorn cleanly

$connections = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
if ($connections) {
    foreach ($conn in $connections) {
        if ($conn.OwningProcess -gt 0) {
            Write-Host "Freeing port 8000 (stopping process $($conn.OwningProcess))..." -ForegroundColor Yellow
            Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
        }
    }
    Start-Sleep -Milliseconds 500
}

Write-Host "Starting SkillProof server on http://127.0.0.1:8000 ..." -ForegroundColor Green
Set-Location -Path $PSScriptRoot
python -m uvicorn app:app --host 127.0.0.1 --port 8000
