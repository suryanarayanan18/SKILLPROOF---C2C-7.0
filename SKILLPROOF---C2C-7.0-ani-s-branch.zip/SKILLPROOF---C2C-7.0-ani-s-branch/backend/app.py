"""FastAPI entry point for the in-memory SkillProof prototype API."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
import sys
import time
from uuid import uuid4


# Ensure backend directory is in sys.path
_backend_dir = str(Path(__file__).resolve().parent)
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)

from dotenv import load_dotenv

# Load .env from backend directory and repository root
load_dotenv(Path(__file__).resolve().parent / ".env")
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

from fastapi import FastAPI, Header, HTTPException, status
from pydantic import BaseModel

class KeyConfigRequest(BaseModel):
    api_key: str
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from normalizers import normalize_challenge, normalize_evaluation
from schemas import (
    AssessmentRecord,
    AssessmentResponse,
    ChallengeCreateRequest,
    ChallengeResponse,
    ChallengeSession,
    EvaluationRequest,
    ExecutionRequest,
    ExecutionResponse,
    HealthResponse,
    HiddenTestCase,
    JDoodleConfigRequest,
    JDoodleStatusResponse,
    PassportResponse,
    SessionAttempt,
    SolutionSubmitRequest,
    TestCaseItem,
    TestRunRequest,
    TestRunResponse,
)
from services.challenge_generator import generate_challenge, _get_dynamic_challenge
from services.evaluator import evaluate_solution
from services.jdoodle import (
    execute_code,
    get_jdoodle_credentials,
    is_jdoodle_configured,
)
from services.test_runner import run_test_suite

app = FastAPI(title="SkillProof API", version="0.1.0")
logger = logging.getLogger("skillproof.api")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
        "*",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Deliberately process-local for the prototype. Restarting the server clears it.
ASSESSMENTS: dict[str, AssessmentRecord] = {}


def _extract_api_key(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    return ""


def _nemotron_error(error: Exception) -> HTTPException:
    # Log the complete exception for operators, but never reveal provider
    # internals or credentials to browser clients.
    logger.exception("Nemotron request failed: %s", type(error).__name__, exc_info=error)
    message = str(error)
    if "NVIDIA_API_KEY" in message or "not set" in message.lower() and "key" in message.lower():
        return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="NVIDIA Nemotron API key is not configured. Please configure NVIDIA_API_KEY.")
    if any(marker in message.upper() for marker in ("429", "RESOURCE_EXHAUSTED", "RESOURCEEXHAUSTED", "QUOTA", "RATE LIMIT", "LIMIT REACHED")):
        return HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="NVIDIA Nemotron API limit reached. Please try again later.")
    return HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"NVIDIA Nemotron live API error: {message}")


@app.get("/api/health", response_model=HealthResponse)
def health() -> HealthResponse:
    has_nemo = bool(os.getenv("NVIDIA_API_KEY", "").strip())
    has_gem = bool(os.getenv("GEMINI_API_KEY", "").strip())
    return HealthResponse(
        status="ok",
        service="skillproof-api",
        provider="nemotron",
        has_gemini_key=has_gem,
        has_nemotron_key=has_nemo,
    )


@app.post("/api/config/key")
def configure_key(payload: KeyConfigRequest):
    key = payload.api_key.strip()
    if not key:
        raise HTTPException(status_code=400, detail="API key cannot be empty.")
    os.environ["NVIDIA_API_KEY"] = key
    for target in [Path(__file__).resolve().parent / ".env", Path(__file__).resolve().parents[1] / ".env"]:
        try:
            target.write_text(
                f'NVIDIA_API_KEY="{key}"\nNVIDIA_MODEL="{os.getenv("NVIDIA_MODEL", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning")}"\nSKILLPROOF_PROVIDER="nemotron"\n',
                encoding="utf-8",
            )
        except Exception as err:
            logger.warning("Could not persist API key to %s: %s", target, err)
    return {"status": "ok", "message": "NVIDIA Nemotron API key configured successfully."}


@app.post("/api/challenges", response_model=ChallengeResponse, status_code=status.HTTP_201_CREATED)
def create_challenge(
    payload: ChallengeCreateRequest,
    x_nemotron_api_key: str | None = Header(default=None, alias="X-Nemotron-API-Key"),
    x_gemini_api_key: str | None = Header(default=None, alias="X-Gemini-API-Key"),
    x_demo_mode: str | None = Header(default=None, alias="X-Demo-Mode"),
) -> ChallengeResponse:
    key = _extract_api_key(x_nemotron_api_key) or _extract_api_key(x_gemini_api_key)
    if key:
        os.environ["NVIDIA_API_KEY"] = key
    is_demo = (x_demo_mode or "").lower() == "true" or os.getenv("SKILLPROOF_DEMO_MODE", "").lower() == "true"
    if is_demo:
        from services.challenge_generator import _get_dynamic_challenge
        dynamic = _get_dynamic_challenge(str(payload.skill), str(payload.difficulty))
        generated = json.dumps(dynamic)
    else:
        try:
            generated = generate_challenge(
                skill=payload.skill,
                difficulty=payload.difficulty,
                previous_performance=payload.previous_performance,
                target_weakness=payload.target_weakness,
            )
        except Exception as error:
            raise _nemotron_error(error)



    assessment_id = str(uuid4())
    try:
        challenge, hidden_tests = normalize_challenge(
            generated,
            assessment_id=assessment_id,
            challenge_id=f"challenge-{uuid4()}",
            skill=payload.skill,
            difficulty=payload.difficulty,
        )
    except ValueError as ve:
        # AI returned fewer than 3 valid hidden tests — reject this challenge
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Challenge generation failed validation: {ve}",
        )
    session = ChallengeSession(
        assessment_id=assessment_id,
        challenge_id=challenge.challenge_id,
        skill=str(payload.skill),
        difficulty=str(payload.difficulty),
    )
    ASSESSMENTS[assessment_id] = AssessmentRecord(
        **challenge.model_dump(),
        hidden_tests=[ht.model_dump() if hasattr(ht, "model_dump") else ht for ht in hidden_tests],
        session=session,
    )
    return challenge


@app.post("/api/assessments/{assessment_id}/submit", response_model=AssessmentResponse)
def submit_solution(
    assessment_id: str,
    payload: SolutionSubmitRequest,
    x_nemotron_api_key: str | None = Header(default=None, alias="X-Nemotron-API-Key"),
    x_gemini_api_key: str | None = Header(default=None, alias="X-Gemini-API-Key"),
    x_demo_mode: str | None = Header(default=None, alias="X-Demo-Mode"),
) -> AssessmentResponse:

    key = _extract_api_key(x_nemotron_api_key) or _extract_api_key(x_gemini_api_key)
    if key:
        os.environ["NVIDIA_API_KEY"] = key
    assessment = ASSESSMENTS.get(assessment_id)
    if assessment is None:
        # Auto-recover assessment to prevent 404 on server restart or client-seeded sessions
        s_guess = "Python"
        d_guess = "intermediate"
        id_lower = assessment_id.lower()
        if "script" in id_lower or "js" in id_lower:
            s_guess = "JavaScript"
        elif "c++" in id_lower or "cpp" in id_lower or "cplusplus" in id_lower:
            s_guess = "C++"
        elif "html" in id_lower:
            s_guess = "HTML"

        if "beg" in id_lower or "easy" in id_lower:
            d_guess = "beginner"
        elif "adv" in id_lower or "hard" in id_lower:
            d_guess = "advanced"

        recovered_data = _get_dynamic_challenge(s_guess, d_guess)
        recovered_chal_id = f"chal_{s_guess.lower().replace('+', 'p')}_{d_guess}"
        recovered_session = ChallengeSession(
            assessment_id=assessment_id,
            challenge_id=recovered_chal_id,
            skill=s_guess,
            difficulty=d_guess,
        )
        ht_list = [
            HiddenTestCase(**ht) if isinstance(ht, dict) else ht
            for ht in recovered_data.get("hidden_tests", [])
        ]
        assessment = AssessmentRecord(
            assessment_id=assessment_id,
            challenge_id=recovered_chal_id,
            skill=s_guess,
            difficulty=d_guess,
            title=recovered_data.get("title", f"{s_guess} Assessment"),
            overview=recovered_data.get("overview", "Skill assessment challenge."),
            task=recovered_data.get("task", "Implement the required solution."),
            constraints=recovered_data.get("constraints", []),
            starter_code=recovered_data.get("starter_code", ""),
            examples=recovered_data.get("examples", []),
            hidden_tests=ht_list,
            session=recovered_session,
        )
        ASSESSMENTS[assessment_id] = assessment

    # STRICT: Only use backend-stored hidden tests. Never fall back to examples.
    # Examples are visible to the user — using them would allow hardcoded submissions.
    test_cases: list[TestCaseItem] = []
    if assessment.hidden_tests:
        for ht in assessment.hidden_tests:
            if not ht.input.strip() or not ht.expected_output.strip():
                logger.warning("Hidden test '%s' is missing input or expected_output — skipping", ht.name)
                continue
            test_cases.append(
                TestCaseItem(
                    name=ht.name,
                    input=ht.input,
                    expected_output=ht.expected_output,
                )
            )

    # GATE: Require exactly 3 valid hidden tests. 0 tests = UNVERIFIED, never PASS.
    if len(test_cases) < 3:
        logger.error(
            "Assessment %s has only %d valid hidden test(s). Submission blocked as UNVERIFIED.",
            assessment_id, len(test_cases)
        )
        # Return an error response immediately without calling evaluator
        from schemas import EvaluationResponse
        unverified_eval = EvaluationResponse(
            overall_score=0,
            correctness=0,
            problem_solving=0,
            code_quality=0,
            efficiency=0,
            understanding=0,
            practical_application=0,
            summary=(
                f"UNVERIFIED: This submission could not be evaluated because the challenge "
                f"has only {len(test_cases)} hidden test case(s) defined (need 3). "
                f"This is a challenge configuration error, not a reflection of your code."
            ),
            strengths=[],
            weaknesses=["Challenge configuration error: insufficient hidden test cases"],
            feedback="Please retry with a freshly generated challenge.",
            recommended_next_step="Restart the challenge to get a properly configured test suite.",
            status="error",
            passed_tests=0,
            total_tests=len(test_cases),
            failed_tests=0,
            hidden_tests_passed=0,
            hidden_tests_total=3,
            session_retries=0,
            session_submission_count=1,
            improvement_demonstrated=False,
            competency="Unverified",
            improvements=[],
            next_difficulty=None,
            test_results=[],
        )
        assessment.evaluation = unverified_eval
        assessment.submitted_solution = payload.solution
        return assessment


    test_suite_res = run_test_suite(
        code=payload.solution,
        language=str(assessment.skill),
        test_cases=test_cases,
        assessment_id=assessment_id,
    )

    # Session tracking:
    session = assessment.session
    if session is None:
        session = ChallengeSession(
            assessment_id=assessment_id,
            challenge_id=assessment.challenge_id,
            skill=str(assessment.skill),
            difficulty=str(assessment.difficulty),
        )
        assessment.session = session

    session.submission_count += 1
    session.retries = max(0, session.submission_count - 1)

    comp_err = test_suite_res.compiler_error
    run_err = test_suite_res.runtime_error
    if comp_err:
        session.compilation_errors += 1
    if run_err:
        session.runtime_errors += 1
    if test_suite_res.failed > 0:
        session.test_case_failures += 1

    # Check for improvement: e.g. previous attempt had errors or fewer passed tests, and now more tests passed
    prev_passed = session.attempts[-1].passed_tests if session.attempts else 0
    if session.submission_count > 1:
        if test_suite_res.passed > prev_passed or (test_suite_res.passed > 0 and (session.compilation_errors > 0 or session.runtime_errors > 0)):
            session.improvement_demonstrated = True

    attempt = SessionAttempt(
        attempt_number=session.submission_count,
        timestamp=time.time(),
        status=test_suite_res.status,
        passed_tests=test_suite_res.passed,
        total_tests=test_suite_res.total,
        failed_tests=test_suite_res.failed,
        compilation_error=comp_err,
        runtime_error=run_err,
        time_elapsed_seconds=payload.time_elapsed_seconds or 0,
    )
    session.attempts.append(attempt)

    if test_suite_res.status == "PASS":
        session.passed_submissions += 1
    else:
        session.failed_submissions += 1

    test_results_dict = {
        "total": test_suite_res.total,
        "passed": test_suite_res.passed,
        "failed": test_suite_res.failed,
        "status": test_suite_res.status,
        "compiler_error": comp_err,
        "runtime_error": run_err,
        "tests": [
            {
                "name": t.name,
                "status": t.status,
                "input": t.input,
                "expected": t.expected_output,
                "actual": t.actual_output,
                "error": t.error or "",
            }
            for t in test_suite_res.tests
        ],
    }
    session_history_dict = {
        "submission_count": session.submission_count,
        "retries": session.retries,
        "compilation_errors": session.compilation_errors,
        "runtime_errors": session.runtime_errors,
        "test_case_failures": session.test_case_failures,
        "improvement_demonstrated": session.improvement_demonstrated,
    }

    from services.evaluator import _build_deterministic_evaluation

    is_demo = (x_demo_mode or "").lower() == "true" or os.getenv("SKILLPROOF_DEMO_MODE", "").lower() == "true"
    if is_demo:
        generated = _build_deterministic_evaluation(
            challenge=f"{assessment.overview}\n\nTask:\n{assessment.task}\n\nConstraints:\n" + "\n".join(assessment.constraints),
            solution=payload.solution,
            skill=assessment.skill,
            difficulty=assessment.difficulty,
            test_results=test_results_dict,
            session_history=session_history_dict,
        )
    else:
        try:
            generated = evaluate_solution(
                challenge=f"{assessment.overview}\n\nTask:\n{assessment.task}\n\nConstraints:\n" + "\n".join(assessment.constraints),
                solution=payload.solution,
                skill=assessment.skill,
                difficulty=assessment.difficulty,
                test_results=test_results_dict,
                session_history=session_history_dict,
            )
        except Exception as error:
            raise _nemotron_error(error)



    eval_obj = normalize_evaluation(generated)
    if test_suite_res.total > 0:
        eval_obj.total_tests = test_suite_res.total
        eval_obj.passed_tests = test_suite_res.passed
        eval_obj.failed_tests = test_suite_res.failed
        eval_obj.hidden_tests_passed = test_suite_res.passed
        eval_obj.hidden_tests_total = test_suite_res.total
        eval_obj.session_retries = session.retries
        eval_obj.session_submission_count = session.submission_count
        eval_obj.improvement_demonstrated = session.improvement_demonstrated
        eval_obj.test_results = test_results_dict["tests"]

    assessment.evaluation = eval_obj
    assessment.submitted_solution = payload.solution
    assessment.time_elapsed_seconds = payload.time_elapsed_seconds
    return assessment


@app.post("/api/execute", response_model=ExecutionResponse)
def execute_code_endpoint(payload: ExecutionRequest) -> ExecutionResponse:
    """Execute raw code with stdin via JDoodle/runner."""
    res = execute_code(
        code=payload.code,
        language=payload.language,
        stdin=payload.stdin,
    )
    return ExecutionResponse(**res)


@app.post("/api/tests/run", response_model=TestRunResponse)
def run_tests_endpoint(payload: TestRunRequest) -> TestRunResponse:
    """Run test cases against candidate code."""
    test_cases: list[TestCaseItem] = list(payload.custom_tests or payload.tests)
    assessment = None
    if payload.assessment_id:
        assessment = ASSESSMENTS.get(payload.assessment_id)
        # STRICT: Do NOT load examples here — examples are visible to the user.
        # hidden_tests are loaded below.


    language = payload.language
    if assessment and (not language or language == "python"):
        language = str(assessment.skill)

    # STRICT: Use hidden_tests only. Never use examples (visible to user).
    if not test_cases and assessment and assessment.hidden_tests:
        for ht in assessment.hidden_tests:
            if ht.input.strip() and ht.expected_output.strip():
                test_cases.append(
                    TestCaseItem(
                        name=ht.name,
                        input=ht.input,
                        expected_output=ht.expected_output,
                    )
                )

    return run_test_suite(
        code=payload.code,
        language=language,
        test_cases=test_cases,
        assessment_id=payload.assessment_id,
    )


@app.get("/api/jdoodle/status", response_model=JDoodleStatusResponse)
def get_jdoodle_status() -> JDoodleStatusResponse:
    """Check JDoodle configuration status."""
    client_id, client_secret = get_jdoodle_credentials()
    configured = is_jdoodle_configured()
    return JDoodleStatusResponse(
        configured=configured,
        has_client_id=bool(client_id and client_id != "test-client-id"),
        has_client_secret=bool(client_secret and client_secret != "test-client-secret"),
        provider="jdoodle",
    )


@app.post("/api/config/jdoodle")
def configure_jdoodle(payload: JDoodleConfigRequest):
    """Securely store JDoodle credentials into backend .env (backend-only)."""
    c_id = payload.client_id.strip()
    c_sec = payload.client_secret.strip()
    if not c_id or not c_sec:
        raise HTTPException(status_code=400, detail="Both client_id and client_secret are required.")

    os.environ["JDOODLE_CLIENT_ID"] = c_id
    os.environ["JDOODLE_CLIENT_SECRET"] = c_sec

    env_path = Path(__file__).resolve().parent / ".env"
    existing_lines = []
    if env_path.exists():
        existing_lines = env_path.read_text(encoding="utf-8").splitlines()

    new_lines = [l for l in existing_lines if not l.startswith("JDOODLE_CLIENT_ID=") and not l.startswith("JDOODLE_CLIENT_SECRET=")]
    new_lines.append(f"JDOODLE_CLIENT_ID={c_id}")
    new_lines.append(f"JDOODLE_CLIENT_SECRET={c_sec}")
    env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

    return {"status": "ok", "message": "JDoodle credentials configured successfully.", "configured": True}


@app.post("/api/evaluate", response_model=AssessmentResponse)
def evaluate_assessment(payload: EvaluationRequest) -> AssessmentResponse:
    """Compatibility endpoint for clients that submit by assessment_id."""
    return submit_solution(
        payload.assessment_id,
        SolutionSubmitRequest(
            solution=payload.solution,
            time_elapsed_seconds=payload.time_elapsed_seconds,
        ),
    )


@app.get("/api/assessments/{assessment_id}", response_model=AssessmentResponse)
def get_assessment(assessment_id: str) -> AssessmentResponse:
    assessment = ASSESSMENTS.get(assessment_id)
    if assessment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Assessment {assessment_id} not found.",
        )
    return assessment


@app.get("/api/passport", response_model=PassportResponse)
def get_passport() -> PassportResponse:
    completed = [assessment for assessment in ASSESSMENTS.values() if assessment.evaluation]
    if not completed:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No completed assessment is available for a passport.")
    assessment = completed[-1]
    assert assessment.evaluation is not None
    return PassportResponse(
        assessment_id=assessment.assessment_id,
        skill=assessment.skill,
        difficulty=assessment.difficulty,
        overall_score=assessment.evaluation.overall_score,
        verified=assessment.evaluation.overall_score >= 75,
        summary=assessment.evaluation.summary,
    )


# Mount last: API routes above retain precedence while the static
# prototype can be served from the same localhost origin on port 8000.
FRONTEND_DIR = Path(__file__).resolve().parents[1] / "frontend"
if FRONTEND_DIR.is_dir():
    from fastapi.responses import FileResponse

    FRONTEND_ENTRY = FRONTEND_DIR / "index.html"

    @app.get("/", include_in_schema=False)
    @app.get("/index.html", include_in_schema=False)
    def frontend_index() -> FileResponse:
        return FileResponse(FRONTEND_ENTRY)

    @app.get("/skill-selection.html", include_in_schema=False)
    @app.get("/skill-selection", include_in_schema=False)
    @app.get("/assessments.html", include_in_schema=False)
    @app.get("/assessments", include_in_schema=False)
    def page_skill_selection() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skill_selection" / "code.html")

    @app.get("/difficulty-selection.html", include_in_schema=False)
    @app.get("/difficulty-selection", include_in_schema=False)
    def page_difficulty_selection() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "difficulty_selection" / "code.html")

    @app.get("/assessment-setup.html", include_in_schema=False)
    @app.get("/assessment-setup", include_in_schema=False)
    def page_assessment_setup() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "assessment_setup" / "code.html")

    @app.get("/workspace.html", include_in_schema=False)
    @app.get("/workspace", include_in_schema=False)
    def page_workspace() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_challenge_workspace" / "code.html")

    @app.get("/evaluation.html", include_in_schema=False)
    @app.get("/evaluation", include_in_schema=False)
    def page_evaluation() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "ai_evaluation_performance_report" / "code.html")

    @app.get("/passport.html", include_in_schema=False)
    @app.get("/passport", include_in_schema=False)
    @app.get("/skill-passport", include_in_schema=False)
    def page_passport() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_consolidated_skill_passport" / "code.html")

    @app.get("/hub.html", include_in_schema=False)
    @app.get("/hub", include_in_schema=False)
    @app.get("/home", include_in_schema=False)
    def page_hub() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_assessments_hub" / "code.html")

    @app.get("/history.html", include_in_schema=False)
    @app.get("/history", include_in_schema=False)
    @app.get("/assessments-history", include_in_schema=False)
    def page_history() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_assessment_history" / "code.html")

    @app.get("/ai-analysis.html", include_in_schema=False)
    @app.get("/ai-analysis", include_in_schema=False)
    def page_ai_analysis() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_ai_analysis_performance_intelligence" / "code.html")

    @app.get("/console.html", include_in_schema=False)
    @app.get("/console", include_in_schema=False)
    def page_console() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "skillproof_console_ui_system" / "code.html")

    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
