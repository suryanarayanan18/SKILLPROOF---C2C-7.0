import urllib.request
import urllib.parse
import json
import sys

BASE_URL = "http://127.0.0.1:8000"

PAGES = [
    "/",
    "/index.html",
    "/skill_selection/code.html",
    "/difficulty_selection/code.html",
    "/assessment_setup/code.html",
    "/skillproof_challenge_workspace/code.html",
    "/ai_evaluation_performance_report/code.html",
    "/skillproof_consolidated_skill_passport/code.html",
    "/skillproof_assessment_history/code.html",
    "/js/flow.js",
]

def test_routes():
    print(f"Testing routes on {BASE_URL}...")
    for page in PAGES:
        url = BASE_URL + page
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "SkillProofVerifier/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                code = resp.getcode()
                content = resp.read()
                print(f"[OK {code}] {page} ({len(content)} bytes)")
                assert code == 200, f"Expected 200, got {code}"
        except Exception as e:
            print(f"[FAIL] {page}: {e}")
            sys.exit(1)

    print("\nAll frontend routes served with HTTP 200 successfully!")

if __name__ == "__main__":
    test_routes()
